const TPL=document.querySelector('.wrap').outerHTML;
const $=id=>document.getElementById(id);
const NS=[3,3,4,4,4,5,5,5,6,6, 6,7,7,7,8,8,8,8,9,9, 9,9,10,10,10,10,11,11,11,12],PP=NS.map((n,i)=>+(10-6.5*i/(NS.length-1)).toFixed(2));
const LV=NS.map((n,i)=>({n,t:'المستوى '+(i+1)}));
const LIMITS=NS.map((n,i)=>Math.round(n*n*PP[i]));
const PREV=i=>i<5?5:i<8?4:3;
const LI={};let CFG=window.PZ_CONFIG||{};if(!CFG.levels){try{CFG=JSON.parse($('cfg')?.textContent||'{}')||CFG}catch(e){}}
let lvl=0,room='',pieces=[],placed=0,t0=0,timer=0,done=false,W,s,t,Sw,left,phase=0,bid=0,limit=0,custom=null,KS=.55;
const today=new Date().toISOString().slice(0,10);
const ls={get(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
let todayCount=ls.get('pz-count-'+today,0);$('sToday').textContent=todayCount;
let difficulty='normal';
function rng(str){let h=1779033703^str.length;for(let i=0;i<str.length;i++){h=Math.imul(h^str.charCodeAt(i),3432918353);h=h<<13|h>>>19}
let a=h>>>0;return()=>{a|=0;a=a+0x6D2B79F5|0;let x=Math.imul(a^a>>>15,1|a);x=x+Math.imul(x^x>>>7,61|x)^x;return((x^x>>>14)>>>0)/4294967296}}
const seedStr=()=>(isWeekly()?'W'+weekKey():(room||today))+'|'+lvl;
function timeLimit(i){if(i===WEEK_LVL)return WLIMIT;const factor={easy:1.25,normal:1,hard:.85,expert:.7}[difficulty]||1;return Math.max(30,Math.round(LIMITS[i]*factor))}
function art(R){if(custom)return custom;if(LI[lvl])return LI[lvl];return zellij(R);const c=document.createElement('canvas');c.width=c.height=800;const g=c.getContext('2d');
const h=R()*360;let gr=g.createLinearGradient(0,0,800,800);gr.addColorStop(0,`hsl(${h},75%,55%)`);gr.addColorStop(1,`hsl(${(h+70)%360},80%,35%)`);g.fillStyle=gr;g.fillRect(0,0,800,800);
for(let i=0;i<26;i++){g.globalAlpha=.25+R()*.5;g.fillStyle=`hsl(${(h+R()*200)%360},80%,${45+R()*30}%)`;g.beginPath();
if(R()<.6)g.arc(R()*800,R()*800,30+R()*110,0,7);else g.rect(R()*700,R()*700,40+R()*140,40+R()*140);g.fill()}
g.globalAlpha=1;g.fillStyle='#fff5';g.beginPath();g.arc(560+R()*80,160+R()*60,70,0,7);g.fill();
g.lineWidth=14;for(let i=0;i<5;i++){g.strokeStyle=`hsla(${(h+i*40)%360},90%,75%,.55)`;g.beginPath();const y=420+i*70;g.moveTo(0,y);
g.bezierCurveTo(250,y-120+R()*80,500,y+120-R()*80,800,y);g.stroke()}
return c}
function path(g,x,y,sz,e){// e: top,right,bottom,left dirs
const P=[[x,y],[x+sz,y],[x+sz,y+sz],[x,y+sz],[x,y]];g.beginPath();g.moveTo(x,y);
for(let i=0;i<4;i++){const A=P[i],B=P[i+1],dx=B[0]-A[0],dy=B[1]-A[1],k=e[i];
if(!k){g.lineTo(B[0],B[1]);continue}
const nx=dy/sz,ny=-dx/sz,p=(u,v)=>[A[0]+dx*u+nx*v*k*sz,A[1]+dy*u+ny*v*k*sz];
let a=p(.35,0);g.lineTo(...a);
g.bezierCurveTo(...p(.35,.1),...p(.28,.12),...p(.3,.2));
g.bezierCurveTo(...p(.32,.3),...p(.68,.3),...p(.7,.2));
g.bezierCurveTo(...p(.72,.12),...p(.65,.1),...p(.65,0));g.lineTo(B[0],B[1])}
g.closePath()}
function build(){
clearInterval(timer);stopMusic();resetWarn();document.querySelectorAll('.p').forEach(e=>e.remove());pieces=[];placed=0;undoStack=[];redoStack=[];hintCount=0;hintUsed=false;done=false;helpLeft=helpsFor();updHelp();$('stage').classList.remove('paused');$('ov').style.pointerEvents='';if($('hintBtn'))$('hintBtn').disabled=false;$('msg').textContent='';if($('nb'))$('nb').innerHTML='';$('bar').style.width='0';
$('sLvl').textContent=isWeekly()?'★':lvl+1;$('sTime').textContent='0:00';
const R=rng(seedStr()),n=isWeekly()?WN:LV[lvl].n,img=art(R),st=$('stage');
Sw=st.clientWidth;W=Math.min(Sw-4,760,Math.max(300,Math.floor(innerHeight-Math.min(200,Math.round(Sw*.5))-70)));left=(Sw-W)/2;s=W/n;t=s*.25;const dkEl=$('dock'),Td=Math.min(200,Math.round(Sw*.5));dkEl.style.width=dkEl.style.height=Td+'px';const dk=dkEl.getBoundingClientRect(),sr0=st.getBoundingClientRect(),ps=s+2*t,T=Td,dpr=window.devicePixelRatio||1;KS=T*1.1/(1.5*W);
st.style.height=(W+10)+'px';const b=$('board');b.style.cssText=`left:${left}px;width:${W}px;height:${W}px`;
const gh=$('ghost');gh.width=gh.height=W;gh.style.cssText='width:100%;height:100%';gh.getContext('2d').drawImage(img,0,0,W,W);
const H=[],V=[];for(let r=0;r<n;r++){H.push([]);V.push([]);for(let c=0;c<n;c++){H[r].push(R()<.5?1:-1);V[r].push(R()<.5?1:-1)}}
for(let r=0;r<n;r++)for(let c=0;c<n;c++){
const e=[r?-H[r-1][c]:0,c<n-1?V[r][c]:0,r<n-1?H[r][c]:0,c?-V[r][c-1]:0];
const cv=document.createElement('canvas');cv.width=cv.height=ps*dpr;cv.style.width=cv.style.height=ps+'px';cv.className='p';cv.dataset.e=(r===0||c===0||r===n-1||c===n-1)?1:0;
const g=cv.getContext('2d');g.scale(dpr,dpr);g.save();path(g,t,t,s,e);g.clip();g.drawImage(img,t-c*s,t-r*s,W,W);g.restore();
path(g,t,t,s,e);g.lineWidth=1.6;g.strokeStyle='#ffffff90';g.stroke();
const tx=left+c*s-t,ty=r*s-t;cv.dataset.tx=tx;cv.dataset.ty=ty;
cv.style.display='none';cv.style.zIndex=1;cv.style.transform='scale('+KS+')';
st.appendChild(cv);pieces.push(cv)}
const ord=pieces.map((_,i)=>i).sort(()=>Math.random()-.5),cell=T/n;
ord.forEach((pi,k)=>{const el=pieces[pi];el.dataset.hx=(dk.left-sr0.left)+(k%n+.5)*cell-ps/2;el.dataset.hy=(dk.top-sr0.top)+(Math.floor(k/n)+.5)*cell-ps/2});

++bid;clearInterval(timer);limit=timeLimit(lvl);fmt(limit);phase=0;gh.style.opacity=0;ov.style.background='';ov.style.backdropFilter='';ov.style.display='flex';ov.innerHTML='<div class="start-card"><div class="start-emblem"><svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="#3a1a00" stroke-width="1.8" stroke-linejoin="round"><path d="M5 6h4a2 2 0 1 1 4 0h4v4a2 2 0 1 0 0 4v4h-4a2 2 0 1 0-4 0H5v-4a2 2 0 1 1 0-4z"/></svg></div><div class="start-kicker">PUZZLE BYPOINTS · تحدّي التركيز</div><h2 class="start-title">هل أنت مستعد للتحدّي؟</h2><p class="start-desc">رتّب القطع، ركّز في التفاصيل، وأكمل الصورة قبل انتهاء الوقت. خذ نفساً وابدأ عندما تكون جاهزاً.</p><div class="steps"><div><i style="--c:#22d3ee"><svg viewBox="0 0 24 24"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg></i><span>احفظ الصورة</span></div><div><i style="--c:#c084fc"><svg viewBox="0 0 24 24"><path d="M12 3v18M3 12h18M12 3l-3 3m3-3 3 3M12 21l-3-3m3 3 3-3M3 12l3-3m-3 3 3 3M21 12l-3-3m3 3-3 3"/></svg></i><span>اسحب القطع</span></div><div><i style="--c:#4ade80"><svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></i><span>أكمل قبل الوقت</span></div></div><div class="start-tip"><span>✦</span><span>بعد الضغط على «ابدأ اللعب» ستظهر الصورة '+previewSecs()+' ثوانٍ لتحفظها</span><span>✦</span></div></div>';$('msg').style.color='';$('msg').textContent='اللعبة متوقفة مؤقتاً حتى تضغط على «ابدأ اللعب»';$('again').textContent='▶ ابدأ اللعب';$('again').style.display='inline-block';$('again').disabled=false}
// dragging
let cur=null,ox=0,oy=0,zc=100;const stage=$('stage');
stage.addEventListener('pointerdown',ev=>{
if(done||phase!==1||!ev.isPrimary)return;
for(const el of document.elementsFromPoint(ev.clientX,ev.clientY)){
if(!el.classList.contains('p')||el.classList.contains('l'))continue;
const b=el.getBoundingClientRect();
if(!b.width||!b.height)continue;
const uv=rotUV(el,(ev.clientX-b.left)/b.width,(ev.clientY-b.top)/b.height);
const x=Math.max(0,Math.min(el.width-1,Math.floor(uv[0]*el.width)));
const y=Math.max(0,Math.min(el.height-1,Math.floor(uv[1]*el.height)));
let alpha=0;
try{alpha=el.getContext('2d').getImageData(x,y,1,1).data[3]}catch(e){}
if(alpha>20){
ev.preventDefault();
cur=el;
const sr=stage.getBoundingClientRect();
const scaleX=b.width/(el.offsetWidth||1),scaleY=b.height/(el.offsetHeight||1);
ox=(ev.clientX-b.left)/(scaleX||1);
oy=(ev.clientY-b.top)/(scaleY||1);
el.style.transition='none';
el.style.transform='scale(1)';
el.style.left=(ev.clientX-sr.left-ox)+'px';
el.style.top=(ev.clientY-sr.top-oy)+'px';
el.style.zIndex=++zc;
el.style.cursor='grabbing';
vib(8);
try{stage.setPointerCapture(ev.pointerId)}catch(e){}
return;
}
}
});
stage.addEventListener('pointermove',ev=>{
if(!cur)return;
ev.preventDefault();
const sr=stage.getBoundingClientRect();
cur.style.left=(ev.clientX-sr.left-ox)+'px';
cur.style.top=(ev.clientY-sr.top-oy)+'px';
});
const end=()=>{if(!cur)return;const el=cur;cur=null;el.style.cursor='';$('slot').style.display='none';
const dx=el.offsetLeft-el.dataset.tx,dy=el.offsetTop-el.dataset.ty;
if(Math.hypot(dx,dy)<s*.4&&!(el._rot%4)){el.style.left=el.dataset.tx+'px';el.style.top=el.dataset.ty+'px';el.classList.add('l');el.style.zIndex=0;placed++;todayCount++;
ls.set('pz-count-'+today,todayCount);$('sToday').textContent=todayCount;$('bar').style.width=(placed/pieces.length*100)+'%';saveProgress();
if(soundOn)playTone(620,.07);vib(18);onSnap();if(placed===pieces.length)win()}else{try{const bb=$('board').getBoundingClientRect(),q=el.getBoundingClientRect(),mx=q.left+q.width/2,my=q.top+q.height/2;if(mx>bb.left&&mx<bb.right&&my>bb.top&&my<bb.bottom)missCount++}catch(e){}if(soundOn)playTone(180,.06);const dk=$('dock').getBoundingClientRect(),sr=stage.getBoundingClientRect(),cx=sr.left+el.offsetLeft+el.offsetWidth/2,cy=sr.top+el.offsetTop+el.offsetHeight/2;el.style.transition='';if(cx>dk.left&&cx<dk.right&&cy>dk.top&&cy<dk.bottom){el.style.transition='left .3s,top .3s,transform .3s';el.style.left=el.dataset.hx+'px';el.style.top=el.dataset.hy+'px';el.style.transform='scale('+KS+')';el.style.zIndex=1;setTimeout(()=>el.style.transition='',350)}}};
stage.addEventListener('pointerup',end);stage.addEventListener('pointercancel',end);
function win(){done=true;clearInterval(timer);stopMusic();playJingle('win');if(!custom&&!calm&&lvl<LV.length-1&&unl<lvl+1){unl=lvl+1;ls.set('pz-unl-'+(room||today),unl);refreshLv()}$('ghost').style.opacity=1;$('msg').textContent='🎉 اكتملت اللوحة! '+(room?'':'لوحة جديدة بعد منتصف الليل.');
if(lvl<LV.length-1)nextBtn('▶ المستوى التالي',()=>{lvl++;refreshLv();build()});else nextBtn('↻ العب من جديد',()=>{lvl=0;refreshLv();build()});if(lvl<LV.length-1&&!custom&&!calm)$('msg').textContent+=' فُتح المستوى '+(lvl+2)+' 🔓'}
// UI
let unl=0;
const fmt=x=>{$('sTime').textContent=Math.floor(x/60)+':'+String(x%60).padStart(2,'0')};
function loadUnl(){unl=ls.get('pz-unl-'+(room||today),0);lvl=Math.min(unl,LV.length-1);refreshLv()}
function refreshLv(){renderMeta();$('lv').innerHTML='';const U=custom?LV.length-1:unl;LV.forEach((l,i)=>{const b=document.createElement('button'),m=timeLimit(i);b.textContent=(i>U?'🔒 ':'')+l.t+' · '+Math.floor(m/60)+':'+String(m%60).padStart(2,'0');b.className=i===lvl?'on':'';b.disabled=i>U;b.onclick=()=>{lvl=i;refreshLv();build()};$('lv').appendChild(b)})}
function cdTick(n){const e=$('cdn');if(e){e.classList.remove('beat');void e.offsetWidth;e.classList.add('beat');e.classList.toggle('last',n<=3)}if(!soundOn)return;const f=n<=3?880:660;note(f,.16,.09,'sine','fx');setTimeout(()=>note(f*2,.08,.04,'sine','fx'),30)}
function cdGo(){if(!soundOn)return;[784,988,1318.5].forEach((f,i)=>setTimeout(()=>note(f,.22,.1,'triangle','fx'),i*90))}
function preview(){if(phase!==0||!pieces.length)return;phase=3;const my=bid,ov=$('ov'),gh=$('ghost');$('again').style.display='none';let c=previewSecs();
gh.style.opacity=1;ov.style.background='#14060a30';ov.style.backdropFilter='none';
ov.innerHTML='<div class="cdbox"><div class="cdn" id="cdn">'+c+'</div><div class="cdl">👀 احفظ الصورة جيدًا — تبدأ اللعبة بعد لحظات</div></div>';
$('msg').style.color='';$('msg').textContent='';
cdTick(c);const cd=setInterval(()=>{if(my!==bid){clearInterval(cd);return}c--;if(c>0){const e=$('cdn');if(e)e.textContent=c;cdTick(c);return}clearInterval(cd);cdGo();phase=0;startPlay()},1000)}
function startPlay(){if(phase!==0||!pieces.length)return;audioReady();phase=2;$('again').disabled=true;$('again').style.display='none';$('ov').style.display='none';$('ghost').style.opacity=0;pv=0;$('msg').textContent='';
const sr=stage.getBoundingClientRect(),dk=$('dock').getBoundingClientRect(),n=isWeekly()?WN:LV[lvl].n,cell=Math.min(200,Math.round(Sw*.5))/n;
pieces.forEach((el,i)=>{const p=parseFloat(el.style.width)||s+2*t;el.style.display='block';el.style.visibility='visible';el.style.opacity='1';el.style.left=(Sw-p)/2+'px';el.style.top=(W-p)/2+'px';el.style.zIndex='2';el.style.pointerEvents='auto';if(!Number.isFinite(parseFloat(el.dataset.hx))||!Number.isFinite(parseFloat(el.dataset.hy))){el.dataset.hx=(dk.left-sr.left)+(i%n+.5)*cell-p/2;el.dataset.hy=(dk.top-sr.top)+(Math.floor(i/n)+.5)*cell-p/2;}});
void stage.offsetHeight;
pieces.forEach(el=>{el.style.transition='left .6s,top .6s,transform .6s';el.style.left=el.dataset.hx+'px';el.style.top=el.dataset.hy+'px'});
setTimeout(()=>{pieces.forEach(el=>el.style.transition='');phase=1;t0=Date.now();startMusic();restoreProgress();updateHistoryButtons();clearInterval(timer);
timer=setInterval(()=>{if(done||phase!==1)return;if(calm){fmt(Math.floor((Date.now()-t0)/1000));return}const r=limit-Math.floor((Date.now()-t0)/1000);fmt(Math.max(r,0));lowTime(r);if(r<=0)fail()},250)},650)}
function nextBtn(t,f){let nb=$('nb');if(!nb){nb=document.createElement('div');nb.id='nb';nb.style.textAlign='center';$('msg').after(nb)}nb.innerHTML='';const b=document.createElement('button');b.className='pri';b.style.marginTop='10px';b.textContent=t;b.onclick=f;nb.appendChild(b)}
function fail(){if(done)return;done=true;clearInterval(timer);stopMusic();playJingle('lose');nextBtn('↻ أعد المحاولة',build);cur=null;$('slot').style.display='none';$('msg').style.color='#fb7185';$('msg').textContent='⏰ انتهى الوقت! انتهت المحاولة، حاول مرة أخرى.'}
$('again').textContent='▶ ابدأ اللعب';$('again').onclick=()=>{if(phase!==0)return;audioReady();if(audioCtx&&audioCtx.state==='suspended')audioCtx.resume().catch(()=>{});preview()};
let pv=0;if(/^#[A-Za-z0-9]{3,8}$/.test(location.hash)){room=location.hash.slice(1).toUpperCase();$('roomBox').style.display='block';$('roomBox').innerHTML='رمز الغرفة: <b>'+room+'</b>'}
addEventListener('resize',()=>{clearTimeout(window._rz);window._rz=setTimeout(()=>{if(!placed&&$('stage').clientWidth!==Sw)build()},250)});

// ===== إضافات: التلميح، التراجع، الإعادة، الحفظ والإنجازات =====
let undoStack=[],redoStack=[],hintCount=0,hintUsed=false;
const saveKey=()=>`pz-save-${today}-${lvl}`;
const statsKey='pz-extra-stats';
let extraStats=ls.get(statsKey,{wins:0,best:{},streak:0,lastDay:'',achievements:[]});
function toast(t){const x=$('toast');x.textContent=t;x.style.display='block';clearTimeout(window._toastTimer);window._toastTimer=setTimeout(()=>x.style.display='none',2400)}
// إضافات الملف الشخصي والصوت والصعوبة والترتيب المحلي
let soundOn=ls.get('pz-sound',true),audioCtx=null;
let musicOn=ls.get('pz-music',true),musicTimer=null,musicStep=0;
function audioReady(){
  try{
    const AC=window.AudioContext||window.webkitAudioContext;
    if(!AC)return null;
    audioCtx=audioCtx||new AC();
    if(audioCtx.state==='suspended')audioCtx.resume().catch(()=>{});
    return audioCtx;
  }catch(e){return null}
}
// Browsers require a real tap/click before they allow generated audio.
window.addEventListener('pointerdown',()=>audioReady(),{once:true,capture:true});
window.addEventListener('keydown',()=>audioReady(),{once:true});
// Master volume: FX (piece snaps, icon/button clicks) and music each go through a boost gain + limiter.
const FX_BOOST=4,MUSIC_BOOST=5;let fxVol=Math.min(1.5,Math.max(0,+ls.get('pz-fxvol',1)));let musVol=Math.min(1.5,Math.max(0,+ls.get('pz-musvol',1)));if(!isFinite(fxVol))fxVol=1;if(!isFinite(musVol))musVol=1;
function outBus(ctx,channel){
  if(!ctx._bus){
    const comp=ctx.createDynamicsCompressor();
    comp.threshold.value=-10;comp.knee.value=12;comp.ratio.value=12;comp.attack.value=.003;comp.release.value=.2;
    comp.connect(ctx.destination);
    const fx=ctx.createGain(),mu=ctx.createGain();
    fx.gain.value=FX_BOOST*fxVol;mu.gain.value=MUSIC_BOOST*musVol;
    fx.connect(comp);mu.connect(comp);
    ctx._bus={fx,music:mu};
  }
  return channel==='music'?ctx._bus.music:ctx._bus.fx;
}
function note(freq,duration,volume=.018,wave='sine',channel='fx'){
  if(channel==='music'?!musicOn:!soundOn)return;
  const ctx=audioReady();if(!ctx)return;
  const play=()=>{
    if(channel==='music'&&!musicOn)return;
    try{
      const o=ctx.createOscillator(),g=ctx.createGain();
      o.type=wave;o.frequency.setValueAtTime(freq,ctx.currentTime);
      g.gain.setValueAtTime(.0001,ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(Math.max(.0002,volume),ctx.currentTime+.035);
      g.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+duration);
      o.connect(g);g.connect(outBus(ctx,channel));o.start();o.stop(ctx.currentTime+duration+.04);
    }catch(e){}
  };
  if(ctx.state==='running')play();else ctx.resume().then(play).catch(()=>{});
}
function playTone(freq,duration){note(freq,duration,.045,'sine','fx')}
function playUiClick(){
  if(!soundOn)return;
  // Short, soft two-tone tap so every control gives clear feedback.
  note(740,.055,.035,'sine','fx');
  setTimeout(()=>note(988,.045,.022,'sine','fx'),38);
}
// Sound on every button, icon-button, link, and keyboard activation.
// Capture phase ensures the sound starts directly from the user's gesture.
document.addEventListener('pointerdown',ev=>{
  const target=ev.target&&ev.target.closest?ev.target.closest('button,a,[role="button"],.clickable,.icon-btn'):null;
  if(target&&!target.disabled)playUiClick();
},true);
document.addEventListener('keydown',ev=>{
  if(ev.key!=='Enter'&&ev.key!==' ')return;
  const target=ev.target&&ev.target.closest?ev.target.closest('button,a,[role="button"],.clickable,.icon-btn'):null;
  if(target&&!target.disabled)playUiClick();
},true);
function playJingle(kind){
  if(!soundOn)return;
  const winNotes=[523.25,659.25,783.99,1046.5,783.99,1046.5];
  const loseNotes=[392,349.23,329.63,261.63];
  const seq=kind==='win'?winNotes:loseNotes;
  seq.forEach((f,i)=>setTimeout(()=>note(f,kind==='win'?.24:.34,.065,'triangle','fx'),i*(kind==='win'?145:210)));
  if(kind==='win')setTimeout(()=>note(1318.5,.48,.045,'sine','fx'),seq.length*145);
}
function softMusicNote(freq,duration=1.8,volume=.006){
  if(!musicOn)return;
  const ctx=audioReady();if(!ctx)return;
  const play=()=>{
    if(!musicOn)return;
    try{
      const osc=ctx.createOscillator(),gain=ctx.createGain(),filter=ctx.createBiquadFilter();
      osc.type='sine';osc.frequency.setValueAtTime(freq,ctx.currentTime);
      filter.type='lowpass';filter.frequency.setValueAtTime(1250,ctx.currentTime);
      const now=ctx.currentTime;
      gain.gain.setValueAtTime(.0001,now);
      gain.gain.exponentialRampToValueAtTime(volume,now+.32);
      gain.gain.setValueAtTime(volume,now+Math.max(.4,duration-.45));
      gain.gain.exponentialRampToValueAtTime(.0001,now+duration);
      osc.connect(filter);filter.connect(gain);gain.connect(outBus(ctx,'music'));
      osc.start(now);osc.stop(now+duration+.04);
    }catch(e){}
  };
  if(ctx.state==='running')play();else ctx.resume().then(play).catch(()=>{});
}
let warnLast=null,fastMusic=false,musicMs=1450,musicBar=null;
const MUSIC_THEMES=[
 {c:[[261.63,329.63,392.00],[220.00,261.63,329.63],[174.61,220.00,261.63],[196.00,246.94,293.66]],m:[523.25,659.25,587.33,493.88,440.00,493.88,587.33,659.25,523.25,440.00,392.00,440.00,493.88,440.00,392.00,349.23]},
 {c:[[293.66,349.23,440.00],[233.08,293.66,349.23],[196.00,246.94,293.66],[220.00,277.18,329.63]],m:[587.33,698.46,659.25,587.33,523.25,587.33,698.46,783.99,659.25,587.33,523.25,466.16,523.25,587.33,523.25,440.00]},
 {c:[[329.63,392.00,493.88],[261.63,329.63,392.00],[220.00,261.63,329.63],[246.94,311.13,370.00]],m:[659.25,783.99,739.99,659.25,587.33,659.25,783.99,880.00,783.99,659.25,587.33,659.25,739.99,659.25,587.33,493.88]},
 {c:[[196.00,246.94,293.66],[164.81,196.00,246.94],[130.81,164.81,196.00],[146.83,185.00,220.00]],m:[392.00,493.88,440.00,392.00,349.23,392.00,493.88,587.33,493.88,440.00,392.00,349.23,392.00,440.00,392.00,329.63]}
];
function startMusic(){
  if(!musicOn||musicTimer||done)return;
  const ctx=audioReady();
  if(!ctx)return;
  const th=MUSIC_THEMES[((lvl%MUSIC_THEMES.length)+MUSIC_THEMES.length)%MUSIC_THEMES.length],chords=th.c,melody=th.m;
  musicStep=0;musicMs=fastMusic?1050:1450;
  musicBar=()=>{
    if(!musicOn||done){stopMusic();return}
    const chord=chords[Math.floor(musicStep/4)%chords.length];
    chord.forEach((f,i)=>softMusicNote(f/2,2.35,i===0?.010:.007));
    softMusicNote(melody[musicStep%melody.length],1.65,.026);
    musicStep++;
  };
  if(ctx.state==='running')musicBar();
  else ctx.resume().then(()=>{if(musicOn&&!done&&musicBar)musicBar()}).catch(()=>{});
  musicTimer=setInterval(musicBar,musicMs);
}
function setMusicTempo(ms){musicMs=ms;if(musicTimer&&musicBar){clearInterval(musicTimer);musicTimer=setInterval(musicBar,ms)}}
function stopMusic(){if(musicTimer){clearInterval(musicTimer);musicTimer=null}}

const profileKey='pz-profile',boardKey='pz-local-leaderboard';
const profile=Object.assign({name:'لاعب جديد',bio:'',avatar:''},ls.get(profileKey,{})||{});
if($('playerName'))$('playerName').value=profile.name||'';
function profileLevel(){return Math.floor(Math.max(0,pts||0)/500)+1}
function profileLevelProgress(){return Math.max(0,pts||0)%500}
function safeAvatar(){return typeof profile.avatar==='string'&&/^data:image\/(jpeg|png|webp);base64,/.test(profile.avatar)?profile.avatar:''}
function renderProfile(){
 const box=$('profileBox');if(!box)return;
 const playerName=profile.name||'لاعب جديد';
 const name=escapeText(playerName),bio=escapeText(profile.bio||'لم تتم إضافة نبذة بعد.');
 const avatar=safeAvatar(),level=profileLevel(),xp=profileLevelProgress(),points=Math.max(0,pts||0);
 const wins=extraStats.wins||0,stars=totalStars(),streak=streakNow();
 const earned=(typeof BD!=='undefined'?BD.filter(b=>{try{return b[3](extraStats)}catch(e){return false}}):[]);
 const recent=(ls.get('pz-album',[])||[]).slice(-6).reverse();
 const rankNames=(typeof RK!=='undefined'?RK.filter(r=>points>=r[2]).slice(-1):[]);
 const rank=rankNames.length?rankNames[0][0]:'مبتدئ';
 const bestTimes=Object.values(extraStats.best||{}).filter(v=>Number(v)>0).map(Number);
 const bestTime=bestTimes.length?Math.min(...bestTimes):0;
 const avatarMarkup=avatar?'<img class="bp-profile-avatar" src="'+avatar+'" alt="الصورة الشخصية">':'<span class="bp-profile-avatar-fallback" aria-hidden="true">♟</span>';
 const badges=(typeof BD!=='undefined'?BD:[]).map(b=>{
   let unlocked=false;try{unlocked=!!b[3](extraStats)}catch(e){}
   return '<div class="bp-profile-badge'+(unlocked?' is-unlocked':'')+'"><span class="bp-profile-badge-icon">'+(unlocked?'🏅':'🔒')+'</span><span>'+escapeText(b[0])+'</span><small>'+(unlocked?'تم فتحه':'لم يُفتح بعد')+'</small></div>';
 }).join('');
 const history=recent.length?recent.map(item=>'<li><span><b>اللوحة '+(Number(item.l)+1)+'</b><small>وقت الإكمال: '+fm(Number(item.t)||0)+'</small></span><strong>'+'★'.repeat(Math.max(0,Math.min(3,Number(item.s)||0)))+'</strong></li>').join(''):'<li class="bp-profile-empty">أكمل أول لوحة لتظهر نتائجك هنا.</li>';
 const levelCards=Array.from({length:10},(_,i)=>{
   const n=i+1,required=(n-1)*500,unlocked=level>=n,current=level===n;
   return '<div class="bp-profile-level'+(current?' current':unlocked?' unlocked':' locked')+'"><span class="bp-profile-level-icon">'+(unlocked?'♟':'🔒')+'</span><b>المستوى '+n+'</b><small>'+(current?'مستواك الحالي':unlocked?'تم فتحه':'يتطلب '+required.toLocaleString('en-US')+' XP')+'</small></div>';
 }).join('');
 box.innerHTML=
 '<section class="bp-profile-card" aria-label="الملف الشخصي للاعب">'+
   '<div class="bp-profile-cover"><span class="bp-profile-cover-orb"></span><button class="bp-profile-close" id="profileCloseBtn" type="button" aria-label="إغلاق الملف الشخصي">×</button><span class="bp-profile-cover-title">BYPPOINTS PUZZLE</span></div>'+
   '<div class="bp-profile-main">'+
     '<div class="bp-profile-identity"><button class="bp-profile-avatar-button" id="profilePhotoQuick" type="button" aria-label="تغيير الصورة الشخصية">'+avatarMarkup+'<span class="bp-profile-camera">✎</span></button><div class="bp-profile-name"><h2>'+name+'</h2><span class="bp-profile-rank">'+escapeText(rank)+' · المستوى '+level+'</span><p>'+bio+'</p></div></div>'+
     '<div class="bp-profile-xp"><div class="bp-profile-xp-top"><span>تقدم المستوى</span><strong>'+points.toLocaleString('en-US')+' XP إجمالي</strong></div><div class="bp-profile-progress"><span style="width:'+Math.min(100,xp/5)+'%"></span></div><div class="bp-profile-xp-bottom"><span>'+xp+' / 500 XP</span><span>المستوى التالي: '+(level+1)+'</span></div></div>'+
     '<div class="bp-profile-stats"><div><strong>'+wins+'</strong><span>ألواح مكتملة</span></div><div><strong>'+stars+'</strong><span>نجوم مكتسبة</span></div><div><strong>'+earned.length+'</strong><span>إنجازات مفتوحة</span></div><div><strong>'+streak+'</strong><span>أيام لعب متتالية</span></div></div>'+
     '<div class="bp-profile-section-head"><h3>إنجازات اللعبة</h3><span>'+earned.length+' من '+(typeof BD!=='undefined'?BD.length:0)+'</span></div>'+
     '<div class="bp-profile-badges">'+(badges||'<p class="bp-profile-empty">ستظهر إنجازاتك بعد اللعب.</p>')+'</div>'+
     '<div class="bp-profile-section-head"><h3>مسار المستويات</h3><span>10 مستويات</span></div>'+
     '<div class="bp-profile-levels">'+levelCards+'</div>'+
     '<div class="bp-profile-section-head bp-profile-history-head"><h3>آخر اللوحات المكتملة</h3><span>أفضل وقت: '+(bestTime?fm(bestTime):'—')+'</span></div>'+
     '<ol class="bp-profile-history">'+history+'</ol>'+
     '<div class="bp-profile-edit-toggle-row"><button class="bp-profile-edit-toggle" id="profileEditToggle" type="button">✎ تعديل الملف الشخصي</button></div>'+
     '<div class="bp-profile-editor" id="profileEditor" hidden><label for="profileNameInput">اسم اللاعب</label><input id="profileNameInput" maxlength="18" value="'+name+'" placeholder="اكتب اسمك"><label for="profileBioInput">نبذة قصيرة</label><textarea id="profileBioInput" maxlength="120" placeholder="اكتب نبذة قصيرة عنك">'+escapeText(profile.bio||'')+'</textarea><div class="bp-profile-editor-actions"><button type="button" id="profilePhotoBtn">تغيير الصورة</button><button type="button" id="profileRemovePhoto">حذف الصورة</button></div><div class="bp-profile-editor-actions"><button type="button" class="bp-profile-save" id="profileSaveBtn">حفظ التعديلات</button><button type="button" id="profileCancelBtn">إلغاء</button></div><small>تُحفظ بياناتك على هذا الجهاز والمتصفح.</small></div>'+
   '</div></section>';
 $('profilePhotoQuick').onclick=()=>$('profileAvatarInput').click();
 $('profilePhotoBtn').onclick=()=>$('profileAvatarInput').click();
 $('profileRemovePhoto').onclick=()=>{profile.avatar='';ls.set(profileKey,profile);renderProfile();toast('تم حذف الصورة الشخصية')};
 $('profileCloseBtn').onclick=()=>{box.style.display='none'};
 $('profileEditToggle').onclick=()=>{const editor=$('profileEditor');editor.hidden=!editor.hidden;if(!editor.hidden)$('profileNameInput').focus()};
 $('profileCancelBtn').onclick=()=>{renderProfile()};
 $('profileSaveBtn').onclick=()=>{
   profile.name=$('profileNameInput').value.trim().slice(0,18)||'لاعب جديد';
   profile.bio=$('profileBioInput').value.trim().slice(0,120);
   ls.set(profileKey,profile);if($('playerName'))$('playerName').value=profile.name;
   renderProfile();toast('تم حفظ الملف الشخصي');
 };
}
$('profileAvatarInput').onchange=e=>{
 const file=e.target.files&&e.target.files[0];e.target.value='';
 if(!file)return;
 if(!/^image\/(jpeg|png|webp)$/.test(file.type)){toast('يرجى اختيار صورة بصيغة JPG أو PNG أو WEBP');return}
 if(file.size>5*1024*1024){toast('يجب ألا يتجاوز حجم الصورة 5 ميغابايت');return}
 const reader=new FileReader();
 reader.onload=()=>{
   const im=new Image();
   im.onload=()=>{
     const c=document.createElement('canvas'),side=256;c.width=c.height=side;
     const g=c.getContext('2d'),m=Math.min(im.width,im.height),x=(im.width-m)/2,y=(im.height-m)/2;
     g.drawImage(im,x,y,m,m,0,0,side,side);
     profile.avatar=c.toDataURL('image/jpeg',.78);ls.set(profileKey,profile);renderProfile();toast('تم تحديث الصورة الشخصية');
   };
   im.onerror=()=>toast('تعذّر قراءة الصورة المختارة');im.src=reader.result;
 };
 reader.onerror=()=>toast('تعذّر تحميل الصورة');reader.readAsDataURL(file);
};
$('soundToggle').textContent='المؤثرات: '+(soundOn?'مفعّلة':'متوقفة');
$('soundToggle').onclick=()=>{audioReady();soundOn=!soundOn;ls.set('pz-sound',soundOn);$('soundToggle').textContent='المؤثرات: '+(soundOn?'مفعّلة':'متوقفة')};
$('musicToggle').textContent='الموسيقى: '+(musicOn?'مفعّلة':'متوقفة');
$('musicToggle').onclick=()=>{audioReady();musicOn=!musicOn;ls.set('pz-music',musicOn);$('musicToggle').textContent='الموسيقى: '+(musicOn?'مفعّلة':'متوقفة');if(musicOn&&!done&&phase===1)startMusic();else stopMusic()};
function renderLeaderboard(){const box=$('leaderboardBox'),rows=ls.get(boardKey,[]).slice().sort((a,b)=>b.wins-a.wins||a.best-b.best).slice(0,10);box.style.display=box.style.display==='none'?'block':'none';box.innerHTML='<strong>🥇 أفضل اللاعبين على هذا الجهاز</strong><ol class="feature-list">'+(rows.length?rows.map(x=>'<li>'+escapeText(x.name)+' — '+x.wins+' فوز · أفضل وقت '+Math.floor(x.best/60)+':'+String(x.best%60).padStart(2,'0')+'</li>').join(''):'<li>أكمل لوحة لتظهر هنا</li>')+'</ol><small>الترتيب محفوظ محلياً في هذا المتصفح فقط.</small>'}
function escapeText(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

function placedIds(){return pieces.map((p,i)=>p.classList.contains('l')?i:null).filter(x=>x!==null)}
function saveProgress(){if(!room)ls.set(saveKey(),placedIds());ls.set(statsKey,extraStats)}
function updateHistoryButtons(){$('undoBtn').disabled=!undoStack.length;$('redoBtn').disabled=!redoStack.length}
function updateProgressUI(){ $('bar').style.width=(placed/Math.max(1,pieces.length)*100)+'%';$('sToday').textContent=todayCount;updateHistoryButtons();saveProgress() }
function restoreProgress(){if(room)return;const ids=ls.get(saveKey(),[]);if(!Array.isArray(ids)||!ids.length)return;
ids.forEach(i=>{const p=pieces[i];if(!p||p.classList.contains('l'))return;p.classList.add('l');p.style.left=p.dataset.tx+'px';p.style.top=p.dataset.ty+'px';p.style.transform='';p.style.zIndex=0;placed++});
if(placed){todayCount=Math.max(todayCount,placed);ls.set('pz-count-'+today,todayCount);updateProgressUI();toast('تم استرجاع تقدمك المحفوظ تلقائياً')}
}
function undoMove(){if(!undoStack.length||done)return;const p=undoStack.pop();p.classList.remove('l');p.style.left=p.dataset.hx+'px';p.style.top=p.dataset.hy+'px';p.style.transform='scale('+KS+')';p.style.zIndex=1;placed=Math.max(0,placed-1);todayCount=Math.max(0,todayCount-1);ls.set('pz-count-'+today,todayCount);redoStack.push(p);updateProgressUI()}
function redoMove(){if(!redoStack.length||done)return;const p=redoStack.pop();p.classList.add('l');p.style.left=p.dataset.tx+'px';p.style.top=p.dataset.ty+'px';p.style.transform='';p.style.zIndex=0;placed++;todayCount++;ls.set('pz-count-'+today,todayCount);undoStack.push(p);updateProgressUI();if(placed===pieces.length)win()}
$('undoBtn').onclick=undoMove;$('redoBtn').onclick=redoMove;
$('hintBtn').onclick=()=>{if(done||phase!==1){toast('ابدأ اللعب أولاً للحصول على تلميح');return}if(hintUsed){toast('استخدمت التلميح في هذه المحاولة؛ أعد المحاولة للحصول على تلميح جديد');return}hintUsed=true;hintCount++;$('hintBtn').disabled=true;const gh=$('ghost');gh.style.opacity='.72';toast('💡 هذا هو التلميح الوحيد لهذه المحاولة');setTimeout(()=>{if(!done)gh.style.opacity=0},2200)};
$('statsBtn').onclick=()=>{const pb=$('profileBox'),opening=pb.style.display!=='block';pb.style.display=opening?'block':'none';if(opening)renderProfile();const box=$('achievementBox');box.style.display=box.style.display==='none'?'block':'none';const best=Object.values(extraStats.best||{}).filter(Boolean).sort((a,b)=>a-b)[0];box.innerHTML=badgesHTML(best)};
function streakNow(){const d=new Date().toISOString().slice(0,10),y=new Date(Date.now()-86400000).toISOString().slice(0,10);return extraStats.lastDay===d||extraStats.lastDay===y?(extraStats.streak||0):0}
function renderMeta(){const sn=$('stNum');if(!sn)return;sn.textContent=streakNow();const days=extraStats.days||[],wk=$('wk'),nm=['ح','ن','ث','ر','خ','ج','س'];wk.innerHTML='';
for(let i=6;i>=0;i--){const dt=new Date(Date.now()-i*86400000),e=document.createElement('i');e.textContent=nm[dt.getDay()];if(days.includes(dt.toISOString().slice(0,10)))e.className='on';if(i===0)e.classList.add('td');wk.appendChild(e)}
const p=$('path');p.innerHTML='';LV.forEach((l,i)=>{const w=document.createElement('div');w.className='pn';const n=document.createElement('span');n.className='nd'+(i<unl?' done':i===lvl?' cur':'');n.textContent=i+1;w.appendChild(n);if(i<LV.length-1){const u=document.createElement('span');u.className='ln'+(i<unl?' done':'');w.appendChild(u)}p.appendChild(w)})}
function showWin(el){const r=el/Math.max(limit,1);let st=r<.5?3:r<.8?2:1;if(hintUsed)st=Math.min(st,2);if(calm)st=0;lastSt=st;lastEl=el;const k=''+lvl;if(!calm){extraStats.stars=extraStats.stars||{};extraStats.stars[k]=Math.max(extraStats.stars[k]||0,st);ls.set(statsKey,extraStats)}
const P='M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z';
$('winStars').innerHTML=[0,1,2].map(i=>'<svg viewBox="0 0 24 24" class="'+(i<st?'on':'')+'" style="animation-delay:'+(i*.25)+'s"><path d="'+P+'"/></svg>').join('');
const f=x=>Math.floor(x/60)+':'+String(x%60).padStart(2,'0'),b=extraStats.best[k]||el;
$('winChips').innerHTML='<span><b>'+f(el)+'</b>الوقت</span><span><b>'+f(b)+'</b>أفضل وقت</span><span><b>'+(extraStats.streak||1)+'</b>أيام متتالية</span>';
$('winDetails').textContent=(profile.name||'لاعب جديد')+' · '+lvName()+(calm?' · النمط الهادئ لا يُحتسب في الترتيب':'');renderMeta();if(!calm){addPts(50*st+20*(lvl+1));missionWin(el)}confetti();
try{if(calm)throw 0;const th=document.createElement('canvas');th.width=th.height=420;th.getContext('2d').drawImage($('ghost'),0,0,420,420);const al=ls.get('pz-album',[]);al.push({d:new Date().toISOString().slice(0,10),l:lvl,t:el,s:st,i:th.toDataURL('image/jpeg',.82)});ls.set('pz-album',al.slice(-24))}catch(e){}}
const originalWin=win;
win=function(){if(calm){const e0=Math.max(0,Math.floor((Date.now()-t0)/1000));originalWin();showWin(e0);$('winPanel').style.display='flex';$('winNext').textContent=lvl<LV.length-1?'▶ المستوى التالي':'↻ العب من جديد';$('winNext').onclick=()=>{$('winPanel').style.display='none';if(lvl<LV.length-1){lvl++;refreshLv();build()}else{lvl=0;refreshLv();build()}};return}const elapsed=Math.max(0,Math.floor((Date.now()-t0)/1000));extraStats.wins=(extraStats.wins||0)+1;const k=''+lvl;if(!extraStats.best[k]||elapsed<extraStats.best[k])extraStats.best[k]=elapsed;
const day=new Date().toISOString().slice(0,10),y=new Date(Date.now()-86400000).toISOString().slice(0,10);extraStats.streak=extraStats.lastDay===day?extraStats.streak:(extraStats.lastDay===y?extraStats.streak+1:1);extraStats.lastDay=day;extraStats.days=(extraStats.days||[]);if(!extraStats.days.includes(day))extraStats.days.push(day);extraStats.days=extraStats.days.slice(-30);
const ach=extraStats.achievements||(extraStats.achievements=[]);if(!ach.includes('أول انتصار'))ach.push('أول انتصار');if(extraStats.wins>=5&&!ach.includes('محترف البازل'))ach.push('محترف البازل');if(elapsed<60&&!ach.includes('السرعة الذهبية'))ach.push('السرعة الذهبية');if(!hintUsed&&!ach.includes('بدون تلميح'))ach.push('بدون تلميح');if(difficulty==='expert'&&!ach.includes('خبير البازل'))ach.push('خبير البازل');ls.set(statsKey,extraStats);ls.set(saveKey(),[]);const rows=ls.get(boardKey,[]);let row=rows.find(x=>x.name===(profile.name||'لاعب جديد'));if(!row){row={name:profile.name||'لاعب جديد',wins:0,best:elapsed};rows.push(row)}row.wins++;row.best=Math.min(row.best||elapsed,elapsed);ls.set(boardKey,rows);originalWin();showWin(elapsed);$('winPanel').style.display='flex';$('winNext').textContent=lvl<LV.length-1?'▶ المستوى التالي':'↻ العب من جديد';$('winNext').onclick=()=>{$('winPanel').style.display='none';if(lvl<LV.length-1){lvl++;refreshLv();build()}else{lvl=0;refreshLv();build()}};toast('🎉 تم حفظ الفوز والإنجازات')};
$('winClose').onclick=()=>$('winPanel').style.display='none';
// track placements for undo/redo and autosave
const placementObserver=new MutationObserver(records=>{for(const rec of records){if(rec.attributeName==='class'&&rec.target.classList.contains('p')&&rec.target.classList.contains('l')){const p=rec.target;if(!undoStack.includes(p)){undoStack.push(p);redoStack=[];updateHistoryButtons();saveProgress()}}}});
placementObserver.observe($('stage'),{subtree:true,attributes:true,attributeFilter:['class']});

// ===== admin (visible only to the page owner) =====
let adIdx=0;const draft=Object.assign({},CFG.levels||{});
function toCanvas(src){return new Promise(res=>{const im=new Image();im.onload=()=>{const c=document.createElement('canvas');c.width=c.height=800;const g=c.getContext('2d'),m=Math.min(im.width,im.height);g.drawImage(im,(im.width-m)/2,(im.height-m)/2,m,m,0,0,800,800);res(c)};im.onerror=()=>res(null);im.src=src})}
function renderAdm(){const p=$('adminp');p.innerHTML='<h3>⚙ صور المستويات — الزوار سيركّبون الصور التي تختارها</h3>';
LV.forEach((l,i)=>{const r=document.createElement('div');r.className='ar';
r.innerHTML=(draft[i]?'<img src="'+draft[i]+'">':'<div class="ph">تلقائي</div>')+'<span>'+l.t+' · '+(l.n*l.n)+' قطعة</span>';
const b=document.createElement('button');b.textContent='اختيار';b.onclick=()=>{adIdx=i;$('afile').click()};r.appendChild(b);
if(draft[i]){const d=document.createElement('button');d.textContent='✕';d.onclick=()=>{delete draft[i];renderAdm()};r.appendChild(d)}
p.appendChild(r)});
const sv=document.createElement('button');sv.className='pri';sv.textContent='💾 حفظ ونشر';sv.onclick=saveAdm;p.appendChild(sv);
const st=document.createElement('div');st.id='astat';st.style.cssText='margin-top:8px;font-size:13px;color:var(--mut)';p.appendChild(st)}
$('afile').onchange=e=>{const f=e.target.files[0];e.target.value='';if(!f)return;const fr=new FileReader();fr.onload=async()=>{const c=await toCanvas(fr.result);if(!c)return;draft[adIdx]=c.toDataURL('image/jpeg',.8);renderAdm()};fr.readAsDataURL(f)};
$('adm').onclick=()=>{const p=$('adminp'),o=p.style.display==='block';p.style.display=o?'none':'block';if(!o){renderAdm();p.scrollIntoView({behavior:'smooth'})}};
async function saveAdm(){
 const st=$('astat');st.textContent='جارٍ تجهيز النسخة…';
 try{
  const cssNode=$('app-style');
  const appNode=$('app-script');
  const css=cssNode?cssNode.textContent:await fetch('css/style.css').then(r=>{if(!r.ok)throw new Error('CSS');return r.text()});
  const appCode=appNode?appNode.textContent:await fetch('js/app.js').then(r=>{if(!r.ok)throw new Error('JS');return r.text()});
  const cfg=JSON.stringify({levels:draft}).replace(/</g,'\u003c');
  const html='<!DOCTYPE html>\n<html lang="ar" dir="rtl">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n<title>Puzzle ByPoints</title>\n<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;800&display=swap" rel="stylesheet">\n<style id="app-style">'+css+'</style>\n</head>\n<body>\n'+document.querySelector('.wrap').outerHTML+'\n<script type="application/json" id="cfg">'+cfg+'<\/script>\n<script id="app-script">'+appCode+'<\/script>\n</body>\n</html>';
  const blob=new Blob([html],{type:'text/html;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='ByPoints-Puzzle-Standalone.html';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1500);st.textContent='تم تنزيل نسخة اللعبة المستقلة بنجاح.';
 }catch(e){console.error(e);st.textContent='تعذّر تجهيز الملف. افتح اللعبة عبر خادم محلي ثم حاول مجددًا.'}
}
// ===== extras: edge filter, pause, calm mode, album, badges, skins, share =====
let calm=ls.get('pz-calm',false),edgeOnly=false,pausedAt=0,lastSt=0,lastEl=0,skin=ls.get('pz-skin',0);
let vibOn=ls.get('pz-vib',true)!==false;const vib=n=>{if(!vibOn)return;try{navigator.vibrate&&navigator.vibrate(n)}catch(e){}};
const fm=x=>Math.floor(x/60)+':'+String(x%60).padStart(2,'0');
const totalStars=()=>Object.values(extraStats.stars||{}).reduce((a,b)=>a+b,0);
let helpLeft=2;
function updHelp(){const n=$('helpN'),b=$('helpBtn');if(n)n.textContent=helpLeft;if(b)b.disabled=helpLeft<=0}
$('helpBtn').onclick=()=>{if(phase!==1||done){toast('ابدأ اللعب أولاً');return}if(helpLeft<=0){toast('استعملت المساعدتين');return}
const c=pieces.filter(e=>!e.classList.contains('l')&&e!==cur);if(!c.length)return;const el=c[Math.floor(Math.random()*c.length)];
helpLeft--;updHelp();hintUsed=true;el.classList.remove('hid');el.style.visibility='';el.style.transition='left .5s,top .5s,transform .5s';el.style.zIndex=50;el.style.transform='scale(1)';el.style.left=el.dataset.tx+'px';el.style.top=el.dataset.ty+'px';
setTimeout(()=>{el.style.transition='';el.classList.add('l');el.style.zIndex=0;placed++;$('bar').style.width=(placed/pieces.length*100)+'%';saveProgress();if(soundOn)playTone(620,.07);vib(18);if(placed===pieces.length)win()},520);
toast('✨ تم تركيب قطعة تلقائياً — متبقي '+helpLeft)};
function resume(){t0+=Date.now()-pausedAt;phase=1;$('stage').classList.remove('paused');const ov=$('ov');ov.style.display='none';ov.style.pointerEvents='';startMusic()}
$('pauseBtn').onclick=()=>{if(done)return;const ov=$('ov');
if(phase===1){phase=4;pausedAt=Date.now();$('stage').classList.add('paused');stopMusic();ov.style.display='flex';ov.style.pointerEvents='auto';ov.style.background='';ov.style.backdropFilter='';
ov.innerHTML='<div class="start-card"><div class="start-emblem"><svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="#3a1a00" stroke-width="2.4" stroke-linecap="round"><path d="M8 5v14M16 5v14"/></svg></div><h2 class="start-title">اللعبة متوقفة</h2><p class="start-desc">المؤقت متوقف والقطع مخفية. اضغط للمتابعة.</p><button class="pri" id="resumeBtn" style="width:100%">▶ استئناف</button></div>';$('resumeBtn').onclick=resume}
else if(phase===4)resume()};
function calmUI(){const sp=document.querySelector('.st:nth-child(2) span');if(sp)sp.textContent=calm?'الوقت المنقضي':'الوقت المتبقي';$('calmBtn').classList.toggle('act',calm)}
$('calmBtn').onclick=()=>{calm=!calm;ls.set('pz-calm',calm);calmUI();toast(calm?'النمط الهادئ: بلا مؤقت ولا نجوم':'عاد المؤقت والنجوم');build()};
$('albumBtn').onclick=()=>{const b=$('albumBox');if(b.style.display==='block'){b.style.display='none';return}const al=ls.get('pz-album',[]).slice().reverse();
b.innerHTML='<strong>ألبوم اللوحات المكتملة</strong>'+(al.length?'<div class="album">'+al.map(x=>'<figure><img src="'+x.i+'" alt=""><figcaption><span>'+'★'.repeat(x.s)+'</span><span>'+fm(x.t)+'</span></figcaption></figure>').join('')+'</div>':'<br>لا توجد لوحات بعد، أكمل لوحتك الأولى لتظهر هنا.');b.style.display='block'};
const BD=[['أول انتصار','#4ade80','M5 12.5l4.5 4.5L19 7.5',x=>(x.wins||0)>=1],['السرعة الذهبية','#fbbf24','M13 2 4 14h6l-1 8 9-12h-6z',x=>(x.achievements||[]).includes('السرعة الذهبية')],['بدون تلميح','#22d3ee','M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',x=>(x.achievements||[]).includes('بدون تلميح')],['محترف البازل','#f5c451','M3 8l4 4 5-7 5 7 4-4-2 11H5z',x=>(x.wins||0)>=5],['3 أيام متتالية','#fb923c','M12 2c1 4 5 5.5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 .3 1.2 1 2 2 2 0-3-1-5 1-8z',x=>(x.streak||0)>=3],['10 نجوم','#c084fc','M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z',x=>totalStars()>=10]];
function badgesHTML(best){const x=extraStats;return '<strong>إنجازاتك وإحصائياتك</strong><div class="chips" style="margin:10px 0"><span><b>'+(x.wins||0)+'</b>ألواح مكتملة</span><span><b>'+(best?fm(best):'—')+'</b>أفضل وقت</span><span><b>'+streakNow()+'</b>أيام متتالية</span><span><b>'+totalStars()+'</b>نجمة</span></div><div class="bds">'+BD.map(b=>'<div class="bd'+(b[3](x)?'':' lock')+'"><i style="--c:'+b[1]+'"><svg viewBox="0 0 24 24"><path d="'+b[2]+'"/></svg></i><span>'+b[0]+'</span></div>').join('')+'</div>'}
const SK=[['الذهبي','#f5c451',0],['الياقوتي','#ef4a63',6],['الملكي','#60a5fa',15],['الزمردي','#34d399',30]];
function applySkin(){const k=SK[skin]||SK[0];document.documentElement.style.setProperty('--sk',k[1]);$('skinBtn').textContent=k[0]}
$('skinBtn').onclick=()=>{const ts=totalStars();let n=skin,i=0;do{n=(n+1)%SK.length;i++}while(SK[n][2]>ts&&i<SK.length);
if(n===skin||SK[n][2]>ts){const nx=SK.find(k=>k[2]>ts);toast(nx?'اجمع '+nx[2]+' نجمة لفتح المظهر '+nx[0]:'لا توجد مظاهر أخرى');return}skin=n;ls.set('pz-skin',skin);applySkin()};
$('winShare').onclick=async()=>{try{const W2=1080,H2=1350,c=document.createElement('canvas');c.width=W2;c.height=H2;const g=c.getContext('2d');
const bg=g.createLinearGradient(0,0,W2,H2);bg.addColorStop(0,'#4a0814');bg.addColorStop(1,'#14060a');g.fillStyle=bg;g.fillRect(0,0,W2,H2);
g.strokeStyle='#f5c451';g.lineWidth=8;g.strokeRect(30,30,W2-60,H2-60);
const lg=await new Promise(r=>{const i=new Image();i.onload=()=>r(i);i.onerror=()=>r(null);i.src=document.querySelector('.logo').src});if(lg)g.drawImage(lg,240,60,600,400);
g.save();g.shadowColor='#000';g.shadowBlur=30;g.drawImage($('ghost'),220,490,640,640);g.restore();g.strokeStyle='#f5c451';g.lineWidth=6;g.strokeRect(220,490,640,640);
const P=new Path2D('M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z');
for(let i=0;i<3;i++){g.save();g.translate(380+i*130,1150);g.scale(5,5);g.fillStyle=i<lastSt?'#f5c451':'#ffffff18';g.fill(P);g.lineWidth=.4;g.strokeStyle='#fff1b8';g.stroke(P);g.restore()}
g.fillStyle='#ffe9b0';g.textAlign='center';g.font='bold 52px Tajawal,sans-serif';g.fillText(translateUIString(lvName()+' · '+fm(lastEl)),W2/2,1300);
const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',.9)),file=new File([blob],'puzzle-bypoints.jpg',{type:'image/jpeg'}),txt=translateUIString('أكملت لوحة '+lvName()+' في '+fm(lastEl))+' - Puzzle ByPoints';
if(navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({files:[file],text:txt});return}
if(navigator.share){await navigator.share({text:txt});return}
await navigator.clipboard.writeText(txt);toast('تم نسخ النتيجة')}catch(e){if(!e||e.name!=='AbortError')toast('تعذّرت المشاركة')}};
applySkin();calmUI();
// ===== extras 2: points, ranks, missions, zellij art, confetti, defeat panel =====
let pts=ls.get('pz-pts',0),combo=0,lastSnap=0;
const RK=[['مبتدئ','#94a3b8',0],['هاوٍ','#34d399',300],['محترف','#60a5fa',1000],['خبير','#c084fc',2500],['أسطورة','#f5c451',6000]];
function renderRank(){let i=0;RK.forEach((r,k)=>{if(pts>=r[2])i=k});const r=RK[i],nx=RK[i+1],el=$('rankBox');if(!el)return;const pr=nx?Math.round((pts-r[2])/(nx[2]-r[2])*100):100;
el.innerHTML='<span class="rk" style="--c:'+r[1]+'"><svg viewBox="0 0 24 24"><path d="M3 8l4 4 5-7 5 7 4-4-2 11H5z"/></svg></span><div class="rtx"><b>'+r[0]+'</b><small>'+pts+' نقطة'+(nx?' · '+(nx[2]-pts)+' للرتبة '+nx[0]:'')+'</small><div class="rbar"><div style="width:'+pr+'%"></div></div></div><span class="combo" id="combo"></span>'}
function addPts(n){pts+=n;ls.set('pz-pts',pts);renderRank()}
function onSnap(){if(calm)return;const now=Date.now();combo=now-lastSnap<5000?Math.min(combo+1,5):1;lastSnap=now;addPts(10*combo);if(combo>=2){const e=$('combo');if(e){e.textContent='×'+combo;e.className='combo pop'}}}
const mKey=()=>'pz-miss-'+today,mst=()=>ls.get(mKey(),{w:0,nh:0,fast:0,claimed:false});
const MS=[['أكمل لوحتين','w',2],['أكمل لوحة بلا تلميح','nh',1],['أكمل لوحة في أقل من 3 دقائق','fast',1]];
function missionWin(el){const m=mst();m.w++;if(!hintUsed)m.nh++;if(el<180)m.fast++;ls.set(mKey(),m);renderMissions()}
function renderMissions(){const b=$('missions');if(!b)return;const m=mst(),all=MS.every(x=>m[x[1]]>=x[2]);
b.innerHTML='<div class="mh"><b>مهام اليوم</b><small>'+MS.filter(x=>m[x[1]]>=x[2]).length+' / 3</small></div>'+MS.map(x=>{const d=Math.min(m[x[1]],x[2]),ok=d>=x[2];return '<div class="ms'+(ok?' ok':'')+'"><i><svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></i><span>'+x[0]+'</span><em>'+d+'/'+x[2]+'</em></div>'}).join('')+(all?(m.claimed?'<div class="mc">تم استلام صندوق اليوم ✓</div>':'<button class="pri" id="chestBtn" style="width:100%;margin-top:8px">🎁 افتح صندوق اليوم (+200 نقطة)</button>'):'');
const cb=$('chestBtn');if(cb)cb.onclick=()=>{const m2=mst();m2.claimed=true;ls.set(mKey(),m2);addPts(200);toast('+200 نقطة 🎁');renderMissions()}}
function star8(g,x,y,R1,R2,k,f,st){g.beginPath();for(let i=0;i<k*2;i++){const a=Math.PI*i/k-Math.PI/2,r=i%2?R2:R1;g[i?'lineTo':'moveTo'](x+r*Math.cos(a),y+r*Math.sin(a))}g.closePath();g.fillStyle=f;g.fill();if(st){g.lineWidth=2.5;g.strokeStyle=st;g.stroke()}}
function zellij(R){const c=document.createElement('canvas');c.width=c.height=800;const g=c.getContext('2d');
const PAL=[['#9b1c31','#f5c451','#fff3e0','#14060a','#0f766e'],['#0f5f73','#f5c451','#fff3e0','#06222b','#9b1c31'],['#1d4ed8','#fde68a','#ffffff','#0b1a4a','#0f766e'],['#0f766e','#f5c451','#fff3e0','#04231f','#9b1c31'],['#6d28d9','#f5c451','#fff3e0','#1e0b44','#0f766e']];
const P=PAL[Math.floor(R()*PAL.length)],n=[4,5,6][Math.floor(R()*3)],cs=800/n;g.fillStyle=P[3];g.fillRect(0,0,800,800);
for(let i=0;i<n;i++)for(let j=0;j<n;j++){const cx=(i+.5)*cs,cy=(j+.5)*cs,alt=(i+j)%2,a=R()<.3;
g.fillStyle=alt?P[0]:P[3];g.fillRect(i*cs,j*cs,cs,cs);
star8(g,cx,cy,cs*.5,cs*.3,8,alt?P[3]:(a?P[4]:P[0]),P[1]);star8(g,cx,cy,cs*.34,cs*.2,8,P[1]);star8(g,cx,cy,cs*.22,cs*.13,8,alt?P[0]:(a?P[0]:P[4]));star8(g,cx,cy,cs*.09,cs*.09,4,P[2]);
star8(g,i*cs,j*cs,cs*.1,cs*.1,4,P[1])}
g.lineWidth=10;g.strokeStyle=P[1];g.beginPath();g.arc(400,400,300,0,7);g.stroke();star8(g,400,400,300,215,16,'#00000000',P[2]);star8(g,400,400,110,70,8,P[1],P[3]);star8(g,400,400,60,38,8,P[0],P[2]);
g.strokeStyle=P[1];g.lineWidth=14;g.strokeRect(7,7,786,786);return c}
function confetti(){if(noMotion())return;const c=document.createElement('canvas');c.style.cssText='position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:40';c.width=innerWidth;c.height=innerHeight;document.body.appendChild(c);const g=c.getContext('2d'),cl=['#f5c451','#ef4a63','#fff3e0','#fde68a','#c2283f'],Q=[];
for(let i=0;i<90;i++)Q.push({x:Math.random()*c.width,y:-20-Math.random()*c.height*.4,vx:(Math.random()-.5)*3,vy:2+Math.random()*4,r:Math.random()*6,vr:(Math.random()-.5)*.3,w:6+Math.random()*6,h:8+Math.random()*8,c:cl[i%5]});
let f=0;(function tick(){g.clearRect(0,0,c.width,c.height);Q.forEach(p=>{p.x+=p.vx;p.y+=p.vy;p.r+=p.vr;g.save();g.translate(p.x,p.y);g.rotate(p.r);g.fillStyle=p.c;g.fillRect(-p.w/2,-p.h/2,p.w,p.h);g.restore()});if(++f<170)requestAnimationFrame(tick);else c.remove()})()}
const TIPS=['ابدأ بقطع الإطار ثم انتقل إلى الداخل.','استخدم «الحواف أولاً» لتقليل الازدحام.','ركّز على الألوان والخطوط المتصلة بين القطع.','«التلميح» يساعدك لكنه يخفض نجومك.','جرّب النمط الهادئ للتدرّب بلا وقت.'];
function showFail(){const tot=pieces.length||1,pc=Math.round(placed/tot*100);$('failMsg').textContent='أنجزت '+placed+' من '+tot+' قطعة — كنت قريباً!';$('failBar').style.width='0';setTimeout(()=>$('failBar').style.width=pc+'%',60);
$('failChips').innerHTML='<span><b>'+pc+'%</b>من اللوحة</span><span><b>'+fm(limit)+'</b>الوقت المحدد</span><span><b>'+(isWeekly()?'★':(lvl+1))+'</b>المستوى</span>';$('failTip').textContent='نصيحة: '+TIPS[Math.floor(Math.random()*TIPS.length)];$('failPanel').style.display='flex'}
$('failRetry').onclick=()=>{$('failPanel').style.display='none';build();setTimeout(()=>{if(phase===0)preview()},60)};
$('failClose').onclick=()=>$('failPanel').style.display='none';
const _fail=fail;fail=function(){_fail();try{playJingle('lose')}catch(e){}showFail()};

// ===== v3: volume sliders, low-time warning, snap glow, difficulty, accessibility =====
function noMotion(){try{return document.body.classList.contains('rm')||matchMedia('(prefers-reduced-motion: reduce)').matches}catch(e){return false}}
function applyVol(){const c=audioCtx;if(c&&c._bus){c._bus.fx.gain.value=FX_BOOST*fxVol;c._bus.music.gain.value=MUSIC_BOOST*musVol}}
function bindVol(id,out,get,set,key,sample){
  const el=$(id),o=$(out);if(!el||!o)return;
  el.value=Math.round(get()*100);o.textContent=el.value+'%';
  el.addEventListener('input',()=>{set(el.value/100);o.textContent=el.value+'%';ls.set(key,el.value/100);audioReady();applyVol()});
  if(sample)el.addEventListener('change',sample);
}
bindVol('fxVol','fxVolV',()=>fxVol,v=>{fxVol=v},'pz-fxvol',()=>{if(soundOn)playTone(620,.07)});
bindVol('musVol','musVolV',()=>musVol,v=>{musVol=v},'pz-musvol',null);

function resetWarn(){warnLast=null;fastMusic=false;musicMs=1450;const e=document.querySelector('.st:nth-child(2)');if(e)e.classList.remove('warn')}
function lowTime(r){
  if(calm)return;
  const e=document.querySelector('.st:nth-child(2)');
  if(r<=15&&!fastMusic){fastMusic=true;setMusicTempo(1050)}
  if(r<=10&&r>0){
    if(e)e.classList.add('warn');
    if(r!==warnLast){warnLast=r;if(soundOn)note(r<=3?1175:880,.09,.07,'triangle','fx')}
  }
}



// accessibility toggles
let hcOn=ls.get('pz-hc',false),rmOn=ls.get('pz-rm',false);
function renderA11y(){document.body.classList.toggle('hc',!!hcOn);document.body.classList.toggle('rm',!!rmOn);
  const h=$('hcToggle'),m=$('rmToggle'),v=$('vibToggle');
  h.textContent='التباين العالي: '+(hcOn?'مفعّل':'متوقف');h.setAttribute('aria-pressed',!!hcOn);
  m.textContent='تقليل الحركة: '+(rmOn?'مفعّل':'متوقف');m.setAttribute('aria-pressed',!!rmOn);
  v.textContent='الاهتزاز: '+(vibOn?'مفعّل':'متوقف');v.setAttribute('aria-pressed',!!vibOn)}
$('hcToggle').onclick=()=>{hcOn=!hcOn;ls.set('pz-hc',hcOn);renderA11y()};
$('rmToggle').onclick=()=>{rmOn=!rmOn;ls.set('pz-rm',rmOn);renderA11y()};
$('vibToggle').onclick=()=>{vibOn=!vibOn;ls.set('pz-vib',vibOn);renderA11y();if(vibOn)vib(30)};
renderA11y();
const sp=$('settingsPanel');let spFocus=null,spPaused=false;
function openSettings(){spFocus=document.activeElement;if(phase===1){spPaused=true;$('pauseBtn').click()}sp.style.display='flex';$('settingsClose').focus()}
function closeSettings(){sp.style.display='none';if(spPaused){spPaused=false;if(phase===4)$('pauseBtn').click()}if(spFocus&&spFocus.focus)spFocus.focus()}
$('settingsBtn').onclick=openSettings;$('settingsClose').onclick=closeSettings;
sp.addEventListener('pointerdown',e=>{if(e.target===sp)closeSettings()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&sp.style.display==='flex')closeSettings()});
$('musVol').addEventListener('change',()=>{if(musicOn)softMusicNote(523.25,1.2,.026)});

// ===== v4: weekly challenge, rotation, keyboard, replay, album zoom, achievements, skins, PWA =====
const WEEK_LVL=LV.length,WN=12,WLIMIT=475;
function previewSecs(){return isWeekly()?3:(lvl<10?7:lvl<20?5:3)}
function helpsFor(){return isWeekly()?1:(lvl<10?2:lvl<20?1:0)}
const isWeekly=()=>lvl===WEEK_LVL;
const lvName=()=>isWeekly()?'التحدي الأسبوعي':'المستوى '+(lvl+1);
function weekKey(){const p=today.split('-').map(Number),d=new Date(Date.UTC(p[0],p[1]-1,p[2]));d.setUTCDate(d.getUTCDate()+4-(d.getUTCDay()||7));const y=d.getUTCFullYear(),w=Math.ceil(((d-Date.UTC(y,0,1))/86400000+1)/7);return y+'-W'+String(w).padStart(2,'0')}
let missCount=0,repLog=[],replayTok=0,replaying=false;
function rotUV(el,u,v){switch(((el._rot||0)%4+4)%4){case 1:return[v,1-u];case 2:return[1-u,1-v];case 3:return[1-v,u];default:return[u,v]}}

// lose => start again from zero (no saved pieces)
{const _f=fail;fail=function(){const r=_f.apply(this,arguments);try{ls.set(saveKey(),[])}catch(e){}return r}}

// remaining pieces counter
setInterval(()=>{const e=$('remain');if(!e)return;const tot=pieces.length,t=tot?'القطع المتبقية: '+(tot-placed)+' من '+tot:'';if(e._t!==t){e._t=t;e.textContent=t}},300);

// snap glow + replay log + reset rotation on snap
new MutationObserver(rs=>{for(const r of rs){const el=r.target;if(!el.classList||!el.classList.contains('p'))continue;
  if(el.classList.contains('l')){if(!el._g){el._g=true;if(el._rot){el._rot=0;el.style.rotate=''}const i=pieces.indexOf(el);if(i>=0)repLog.push({i,t:Math.max(0,Date.now()-t0)});if(Date.now()-t0<80)continue;el.classList.add('glow');setTimeout(()=>el.classList.remove('glow'),800)}}
  else if(el._g){el._g=false;const i=pieces.indexOf(el);repLog=repLog.filter(x=>x.i!==i)}}}).observe($('stage'),{subtree:true,attributes:true,attributeFilter:['class']});

// ---- rotation mode ----
let rotOn=ls.get('pz-rot',false)===true;
function renderRot(){const b=$('rotToggle');b.textContent='تدوير القطع: '+(rotOn?'مفعّل':'متوقف');b.setAttribute('aria-pressed',rotOn)}
$('rotToggle').onclick=()=>{if((phase===1&&!done)||phase===4){toast('غيّر هذا الخيار قبل بدء اللعبة');return}rotOn=!rotOn;ls.set('pz-rot',rotOn);renderRot();build()};
function rotatePiece(el){if(!el||el.classList.contains('l'))return;el._rot=((el._rot||0)+1)%4;el.style.rotate=el._rot?(el._rot*90)+'deg':'';if(soundOn)note(480,.05,.04,'sine','fx');vib(10)}
let tapInfo=null;
stage.addEventListener('pointerdown',ev=>{kbCancel();tapInfo=(rotOn&&cur)?{el:cur,x:ev.clientX,y:ev.clientY}:null});
stage.addEventListener('pointerup',ev=>{const t=tapInfo;tapInfo=null;if(!t||!rotOn)return;if(Math.hypot(ev.clientX-t.x,ev.clientY-t.y)<8)rotatePiece(t.el)});
{const _s=startPlay;startPlay=function(){const go=phase===0&&pieces.length;if(go){pieces.forEach(el=>{el._rot=rotOn?Math.floor(Math.random()*4):0;el.style.rotate=el._rot?el._rot*90+'deg':''});if(rotOn)setTimeout(()=>toast('🔄 اضغط على القطعة لتدويرها قبل تركيبها'),800)}return _s.apply(this,arguments)}}

// ---- keyboard play ----
let kbSel=-1,kbHold=null,kbR=0,kbC=0;
const kbEl=document.createElement('div');kbEl.id='kbCell';stage.appendChild(kbEl);stage.tabIndex=0;
const kbLive=m=>{const e=$('kbLive');if(e){e.textContent='';setTimeout(()=>{e.textContent=m},30)}};
function kbList(){return pieces.map((p,i)=>i).filter(i=>!pieces[i].classList.contains('l')).sort((a,b)=>(+pieces[a].dataset.hy-+pieces[b].dataset.hy)||(+pieces[a].dataset.hx-+pieces[b].dataset.hx))}
function kbMark(){pieces.forEach((p,i)=>p.classList.toggle('kbsel',i===kbSel&&!p.classList.contains('l')))}
function kbMove(d){const L=kbList();if(!L.length)return;let k=L.indexOf(kbSel);k=k<0?(d>0?0:L.length-1):(k+d+L.length)%L.length;kbSel=L[k];kbMark();kbLive('القطعة '+(k+1)+' من '+L.length)}
function kbShow(){kbEl.style.cssText='display:block;left:'+(left+kbC*s)+'px;top:'+(kbR*s)+'px;width:'+s+'px;height:'+s+'px';if(kbHold){kbHold.style.left=(left+kbC*s-t)+'px';kbHold.style.top=(kbR*s-t)+'px'}}
function kbToDock(el){el.style.transition='left .3s,top .3s,transform .3s';el.style.left=el.dataset.hx+'px';el.style.top=el.dataset.hy+'px';el.style.transform='scale('+KS+')';el.style.zIndex=1;setTimeout(()=>{el.style.transition=''},350)}
function kbPick(){if(kbSel<0||!pieces[kbSel]||pieces[kbSel].classList.contains('l'))kbMove(1);const el=pieces[kbSel];if(!el)return;const n=Math.round(W/s);kbHold=el;kbR=kbC=Math.floor(n/2);el.style.transition='transform .15s';el.style.transform='scale(1)';el.style.zIndex=++zc;kbShow();kbLive('حُملت القطعة. حرّك بالأسهم ثم Enter للإسقاط')}
function kbDrop(){const el=kbHold;if(!el)return;kbHold=null;kbEl.style.display='none';cur=el;end();
  if(el.classList.contains('l')){kbLive('أحسنت، القطعة في مكانها');kbSel=-1;kbMove(1)}else{kbToDock(el);kbLive('مكان خاطئ')}}
function kbCancel(){const el=kbHold;if(!el)return;kbHold=null;kbEl.style.display='none';kbToDock(el)}
function kbReset(){kbSel=-1;kbHold=null;kbEl.style.display='none'}
stage.addEventListener('focus',()=>{if(phase===1)kbLive('اللوحة: الأسهم لاختيار قطعة، Enter لحملها')});
stage.addEventListener('keydown',ev=>{if(phase!==1||done||ev.ctrlKey||ev.metaKey||ev.altKey)return;const k=ev.key;
  if(k==='r'||k==='R'){const el=kbHold||(kbSel>=0?pieces[kbSel]:null);if(el&&rotOn){ev.preventDefault();rotatePiece(el);kbLive('تدوير: '+((el._rot||0)*90)+'°')}return}
  if(kbHold){const n=Math.round(W/s);let dr=0,dc=0;
    if(k==='ArrowLeft')dc=-1;else if(k==='ArrowRight')dc=1;else if(k==='ArrowUp')dr=-1;else if(k==='ArrowDown')dr=1;
    else if(k==='Enter'||k===' '){ev.preventDefault();kbDrop();return}
    else if(k==='Escape'){ev.preventDefault();kbCancel();kbLive('أُلغي الحمل');return}
    else return;
    ev.preventDefault();kbR=Math.min(n-1,Math.max(0,kbR+dr));kbC=Math.min(n-1,Math.max(0,kbC+dc));kbShow();kbLive('الصف '+(kbR+1)+' العمود '+(kbC+1));return}
  if(k==='ArrowRight'||k==='ArrowDown'){ev.preventDefault();kbMove(1)}
  else if(k==='ArrowLeft'||k==='ArrowUp'){ev.preventDefault();kbMove(-1)}
  else if(k==='Enter'||k===' '){ev.preventDefault();kbPick()}});

// ---- build hook (reset per-game state) ----
{const _b=build;build=function(){repLog=[];missCount=0;replayTok++;replaying=false;kbReset();return _b.apply(this,arguments)}}

// ---- replay ----
function replayRun(){if(!repLog.length||replaying)return;replaying=true;const tok=++replayTok,gh=$('ghost');$('winPanel').style.display='none';
  const L=repLog.slice().sort((a,b)=>a.t-b.t),maxT=Math.max(1,L[L.length-1].t),total=Math.min(9000,Math.max(2500,L.length*90));
  pieces.forEach(p=>{p.style.visibility='hidden'});gh.style.opacity=0;
  let prev=-100;
  L.forEach((x,k)=>{const at=Math.max(prev+45,x.t/maxT*total);prev=at;setTimeout(()=>{if(tok!==replayTok)return;const p=pieces[x.i];if(!p)return;p.style.visibility='';p.classList.add('glow');setTimeout(()=>p.classList.remove('glow'),700);if(soundOn)note(420+(k%8)*55,.06,.04,'sine','fx')},at)});
  setTimeout(()=>{if(tok!==replayTok)return;pieces.forEach(p=>{p.style.visibility=''});gh.style.opacity=1;replaying=false;$('winPanel').style.display='flex'},prev+1100)}
$('winReplay').onclick=replayRun;

// ---- album zoom ----
function closeLb(){$('lightbox').style.display='none'}
function openLb(f){const img=f.querySelector('img');if(!img)return;const sp=f.querySelectorAll('figcaption span');$('lbImg').src=img.src;$('lbDl').href=img.src;$('lbCap').textContent=Array.from(sp).map(x=>x.textContent).join(' · ');$('lightbox').style.display='flex';$('lbClose').focus()}
{const _a=$('albumBtn').onclick;$('albumBtn').onclick=function(){const r=_a.apply(this,arguments);$('albumBox').querySelectorAll('figure').forEach(f=>{f.tabIndex=0;f.setAttribute('role','button');f.setAttribute('aria-label','تكبير اللوحة')});return r}}
$('albumBox').addEventListener('click',e=>{const f=e.target.closest&&e.target.closest('figure');if(f)openLb(f)});
$('albumBox').addEventListener('keydown',e=>{if(e.key!=='Enter'&&e.key!==' ')return;const f=e.target.closest&&e.target.closest('figure');if(f){e.preventDefault();openLb(f)}});
$('lbClose').onclick=closeLb;$('lightbox').addEventListener('pointerdown',e=>{if(e.target===$('lightbox'))closeLb()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('lightbox').style.display==='flex')closeLb()});

// ---- achievements, popups, skins ----
BD.push(
 ['عشر ألواح','#4ade80','M4 6h16M4 12h16M4 18h10',x=>(x.wins||0)>=10],
 ['لوحة بلا خطأ','#22d3ee','M12 3l8 4v5c0 5-3.5 8-8 9-4.5-1-8-4-8-9V7z',x=>(x.achievements||[]).includes('لوحة بلا خطأ')],
 ['سلسلة 7 أيام','#fb923c','M12 2c1 4 5 5.5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 .3 1.2 1 2 2 2 0-3-1-5 1-8z',x=>Math.max(x.maxStreak||0,x.streak||0)>=7],
 ['نجم متألق','#fbbf24','M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z',x=>(x.achievements||[]).includes('نجم متألق')],
 ['30 نجمة','#f472b6','M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z',x=>totalStars()>=30],
 ['بطل الأسبوع','#c084fc','M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3',x=>(x.achievements||[]).includes('بطل الأسبوع')],
 ['ملك التدوير','#818cf8','M21 12a9 9 0 1 1-3-6.7M21 4v5h-5',x=>(x.achievements||[]).includes('ملك التدوير')]
);
SK.push(['الفيروزي','#22d3ee',0,7],['الأرجواني','#c084fc',0,30]);
const maxStreakNow=()=>Math.max(extraStats.maxStreak||0,extraStats.streak||0);
const skinOk=k=>totalStars()>=k[2]&&maxStreakNow()>=(k[3]||0);
$('skinBtn').onclick=()=>{let n=skin,i=0;do{n=(n+1)%SK.length;i++}while(!skinOk(SK[n])&&i<SK.length);
  if(n===skin||!skinOk(SK[n])){const nx=SK.find(k=>!skinOk(k));toast(nx?(nx[3]?'حافظ على '+nx[3]+' أيام متتالية لفتح المظهر '+nx[0]:'اجمع '+nx[2]+' نجمة لفتح المظهر '+nx[0]):'لا توجد مظاهر أخرى');return}
  skin=n;ls.set('pz-skin',skin);applySkin()};
const popQ=[];let popBusy=false;
function nextPop(){const t=popQ.shift();if(!t){popBusy=false;return}popBusy=true;const e=$('achPop');e.textContent=t;e.classList.add('show');if(soundOn)note(880,.12,.06,'triangle','fx');setTimeout(()=>{e.classList.remove('show');setTimeout(nextPop,380)},2600)}
function showPop(t){popQ.push(t);if(!popBusy)nextPop()}
function announceNew(){const seen=extraStats.seenBadges||(extraStats.seenBadges=[]),ss=extraStats.seenSkins||(extraStats.seenSkins=[0]);
  BD.forEach(b=>{if(b[3](extraStats)&&!seen.includes(b[0])){seen.push(b[0]);showPop('🏆 إنجاز جديد: '+b[0])}});
  SK.forEach((k,i)=>{if(skinOk(k)&&!ss.includes(i)){ss.push(i);showPop('🎨 مظهر جديد: '+k[0]+' — جرّبه من الإعدادات')}});
  ls.set(statsKey,extraStats)}
if(!extraStats.seenBadges){extraStats.seenBadges=BD.filter(b=>b[3](extraStats)).map(b=>b[0]);extraStats.seenSkins=SK.map((k,i)=>skinOk(k)?i:-1).filter(i=>i>=0);ls.set(statsKey,extraStats)}

// ---- weekly challenge ----
function renderWeekly(){const b=$('weeklyBtn');if(!b)return;const d=(extraStats.weekly||{})[weekKey()];b.querySelector('span').textContent='التحدي الأسبوعي'+(d?' ✓':'')}
$('weeklyBtn').onclick=()=>{if((phase===1&&!done)||phase===4){toast('أنهِ اللوحة الحالية أو أعد المحاولة أولاً');return}lvl=WEEK_LVL;refreshLv();build()};
{const _w=win;win=function(){const noMiss=missCount===0,rotWin=rotOn,wk=weekKey(),wNow=isWeekly(),isCalm=calm,n0=pieces.length;
  const r=_w.apply(this,arguments);resetWarn();
  try{if(!isCalm){const ach=extraStats.achievements||(extraStats.achievements=[]),add=n=>{if(!ach.includes(n))ach.push(n)};
      if(noMiss&&n0>=9)add('لوحة بلا خطأ');if(rotWin)add('ملك التدوير');
      if(Object.values(extraStats.stars||{}).some(v=>v>=3))add('نجم متألق');
      extraStats.maxStreak=Math.max(extraStats.maxStreak||0,extraStats.streak||0);
      if(wNow){extraStats.weekly=extraStats.weekly||{};if(!extraStats.weekly[wk]){extraStats.weekly[wk]=true;add('بطل الأسبوع');addPts(500);toast('🏆 +500 نقطة — أنجزت التحدي الأسبوعي!')}}
      ls.set(statsKey,extraStats);announceNew()}}catch(e){}
  if(wNow){$('winDetails').textContent='التحدي الأسبوعي'+(isCalm?' · النمط الهادئ لا يُحتسب في الترتيب':'');$('winNext').textContent='↩ العودة إلى المستويات';$('winNext').onclick=()=>{$('winPanel').style.display='none';lvl=Math.min(unl,LV.length-1);refreshLv();build()};renderWeekly()}
  return r}}

// ---- PWA (only when served over http/https) ----
if(/^https?:$/.test(location.protocol)){
  try{const l=document.createElement('link');l.rel='manifest';l.href='manifest.webmanifest';document.head.appendChild(l);
    const a=document.createElement('link');a.rel='apple-touch-icon';a.href='icon-192.png';document.head.appendChild(a)}catch(e){}
  if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
  let dip=null;const ib=$('installBtn');
  addEventListener('beforeinstallprompt',e=>{e.preventDefault();dip=e;ib.style.display='block'});
  ib.onclick=async()=>{if(!dip)return;try{dip.prompt();await dip.userChoice}catch(e){}dip=null;ib.style.display='none'};
  addEventListener('appinstalled',()=>{ib.style.display='none'});
}
renderRot();renderWeekly();
{let lw=innerWidth,tm;addEventListener('resize',()=>{clearTimeout(tm);tm=setTimeout(()=>{if(Math.abs(innerWidth-lw)<2)return;lw=innerWidth;if(phase===0&&!done)build()},300)})}

// ===== v4: translation layer (ar / fr / en) =====
const I18N_TABLE=[["لوحة نركّبها معًا كل يوم. شارك مع الجميع، تقدّم في المستويات، أو العب مع أصدقائك في غرفة خاصة.", "Un tableau à assembler ensemble chaque jour. Partagez avec tous, progressez de niveau en niveau, ou jouez avec vos amis dans une salle privée.", "A picture we put together every day. Share with everyone, climb the levels, or play with friends in a private room."], ["رتّب القطع، ركّز في التفاصيل، وأكمل الصورة قبل انتهاء الوقت. خذ نفساً وابدأ عندما تكون جاهزاً.", "Placez les pièces, concentrez-vous sur les détails et terminez l’image avant la fin du temps. Respirez et commencez quand vous êtes prêt.", "Place the pieces, focus on the details and finish the picture before time runs out. Take a breath and start when you are ready."], ["استخدمت التلميح في هذه المحاولة؛ أعد المحاولة للحصول على تلميح جديد", "Vous avez utilisé l’indice pour cet essai ; recommencez pour en obtenir un nouveau", "You used the hint in this attempt; try again to get a new one"], ["تُفتح مظاهر جديدة بجمع النجوم وبسلسلة 7 و30 يومًا متتالية.", "De nouveaux styles se débloquent avec les étoiles et des séries de 7 et 30 jours d’affilée.", "New styles unlock with stars and with 7- and 30-day streaks."], ["بعد الضغط على «ابدأ اللعب» ستظهر الصورة 7 ثوانٍ لتحفظها", "Après avoir appuyé sur « Jouer », l’image s’affiche 7 secondes pour la mémoriser", "After you press “Start playing”, the picture is shown for 7 seconds so you can memorize it"], ["صور المستويات — الزوار سيركّبون الصور التي تختارها", "Images des niveaux — les visiteurs assembleront les images que vous choisissez", "Level images — visitors will assemble the pictures you choose"], ["لا توجد لوحات بعد، أكمل لوحتك الأولى لتظهر هنا.", "Aucun tableau pour l’instant : terminez le premier pour qu’il apparaisse ici.", "No pictures yet — complete your first one to see it here."], ["اللعبة متوقفة مؤقتاً حتى تضغط على «ابدأ اللعب»", "Le jeu est en pause jusqu’à ce que vous appuyiez sur « Jouer »", "The game is paused until you press “Start playing”"], ["انتهى الوقت! انتهت المحاولة، حاول مرة أخرى.", "Temps écoulé ! Essai terminé, réessayez.", "Time’s up! Attempt over, try again."], ["ركّز على الألوان والخطوط المتصلة بين القطع.", "Concentrez-vous sur les couleurs et les lignes qui se prolongent entre les pièces.", "Focus on the colors and lines that continue between pieces."], ["إحصائياتك وإنجازاتك محفوظة على هذا الجهاز.", "Vos statistiques et succès sont enregistrés sur cet appareil.", "Your stats and achievements are saved on this device."], ["احفظ الصورة جيدًا — تبدأ اللعبة بعد لحظات", "Mémorisez bien l’image — le jeu commence dans un instant", "Memorize the picture well — the game starts in a moment"], ["المؤقت متوقف والقطع مخفية. اضغط للمتابعة.", "Le minuteur est arrêté et les pièces sont cachées. Appuyez pour continuer.", "The timer is stopped and the pieces are hidden. Press to continue."], ["أنهِ اللوحة الحالية أو أعد المحاولة أولاً", "Terminez le tableau en cours ou recommencez d’abord", "Finish the current picture or retry first"], ["الترتيب محفوظ محلياً في هذا المتصفح فقط.", "Le classement est enregistré uniquement dans ce navigateur.", "Ranking is saved only in this browser."], ["للوصول إلى اللوحة، الأسهم لاختيار قطعة،", "pour atteindre le plateau, les flèches pour choisir une pièce,", "to reach the board, arrows to choose a piece,"], ["استخدم «الحواف أولاً» لتقليل الازدحام.", "Utilisez « Bords d’abord » pour réduire l’encombrement.", "Use “Edges first” to reduce clutter."], ["ابدأ بقطع الإطار ثم انتقل إلى الداخل.", "Commencez par les pièces de bord, puis allez vers l’intérieur.", "Start with the frame pieces, then move inward."], ["تم تنزيل نسخة اللعبة المستقلة بنجاح.", "Copie autonome du jeu téléchargée.", "Standalone copy downloaded."], ["اضغط على القطعة لتدويرها قبل تركيبها", "Touchez la pièce pour la faire pivoter avant de la placer", "Tap a piece to rotate it before placing it"], ["هذا هو التلميح الوحيد لهذه المحاولة", "C’est le seul indice de cet essai", "This is the only hint for this attempt"], ["جرّب النمط الهادئ للتدرّب بلا وقت.", "Essayez le mode calme pour vous entraîner sans limite de temps.", "Try calm mode to practice without a time limit."], ["ابدأ اللعب أولاً للحصول على تلميح", "Commencez à jouer pour obtenir un indice", "Start playing first to get a hint"], ["تم استرجاع تقدمك المحفوظ تلقائياً", "Votre progression a été restaurée automatiquement", "Your saved progress was restored automatically"], ["النمط الهادئ لا يُحتسب في الترتيب", "Le mode calme ne compte pas au classement", "Calm mode does not count toward the ranking"], ["«التلميح» يساعدك لكنه يخفض نجومك.", "L’« indice » vous aide mais réduit vos étoiles.", "The “Hint” helps you but lowers your stars."], ["تم حفظ ملف اللاعب على هذا الجهاز", "Profil enregistré sur cet appareil", "Profile saved on this device"], ["إحصائياتك محفوظة على هذا الجهاز.", "Vos statistiques sont enregistrées sur cet appareil.", "Your stats are saved on this device."], ["النمط الهادئ: بلا مؤقت ولا نجوم", "Mode calme : sans minuteur ni étoiles", "Calm mode: no timer, no stars"], ["تم تركيب قطعة تلقائياً — متبقي", "Une pièce a été placée automatiquement — restant :", "A piece was placed automatically — left:"], ["غيّر هذا الخيار قبل بدء اللعبة", "Changez cette option avant de commencer", "Change this option before starting"], ["نقطة — أنجزت التحدي الأسبوعي!", "points — défi de la semaine terminé !", "points — weekly challenge completed!"], ["حُملت القطعة. حرّك بالأسهم ثم", "Pièce prise. Déplacez avec les flèches puis", "Piece picked up. Move with the arrows then"], ["أفضل اللاعبين على هذا الجهاز", "Meilleurs joueurs sur cet appareil", "Top players on this device"], ["افتح صندوق اليوم (+200 نقطة)", "Ouvrir le coffre du jour (+200 points)", "Open the daily chest (+200 points)"], ["اللوحة: الأسهم لاختيار قطعة،", "Plateau : flèches pour choisir une pièce,", "Board: arrows to choose a piece,"], ["لوحة جديدة بعد منتصف الليل.", "Nouveau tableau après minuit.", "A new picture after midnight."], ["أكمل لوحة في أقل من 3 دقائق", "Terminez un tableau en moins de 3 minutes", "Complete a picture in under 3 minutes"], ["اللعب بلوحة المفاتيح: اضغط", "Jouer au clavier : appuyez sur", "Keyboard play: press"], ["لحملها، الأسهم لتحريكها،", "pour la prendre, les flèches pour la déplacer,", "to pick it up, arrows to move it,"], ["تم حفظ الفوز والإنجازات", "Victoire et succès enregistrés", "Win and achievements saved"], ["تم استلام صندوق اليوم ✓", "Coffre du jour récupéré ✓", "Daily chest claimed ✓"], ["أحسنت، القطعة في مكانها", "Bien joué, la pièce est en place", "Well done, the piece is in place"], ["ألبوم اللوحات المكتملة", "Album des tableaux terminés", "Completed pictures album"], ["هل أنت مستعد للتحدّي؟", "Prêt à relever le défi ?", "Ready for the challenge?"], ["— جرّبه من الإعدادات", "— essayez-le dans les réglages", "— try it in settings"], ["العودة إلى المستويات", "Retour aux niveaux", "Back to levels"], ["أكمل لوحة لتظهر هنا", "Terminez un tableau pour apparaître ici", "Complete a picture to appear here"], ["إنجازاتك وإحصائياتك", "Vos succès et statistiques", "Your achievements and stats"], ["أكمل لوحة بلا تلميح", "Terminez un tableau sans indice", "Complete a picture without hints"], ["عرض الترتيب المحلي", "Voir le classement local", "Show local ranking"], ["مستوى صوت المؤثرات", "Volume des effets", "Effects volume"], ["مستوى صوت الموسيقى", "Volume de la musique", "Music volume"], ["أكملت اللوحة بنجاح", "Tableau terminé avec succès", "Picture completed successfully"], ["جارٍ تجهيز النسخة…", "Préparation de la copie…", "Preparing the copy…"], ["تعذّر تجهيز الملف.", "Impossible de préparer le fichier.", "Could not prepare the file."], ["استعملت المساعدتين", "Vous avez utilisé les deux aides", "You used both helps"], ["عاد المؤقت والنجوم", "Le minuteur et les étoiles sont de retour", "Timer and stars are back"], ["لا توجد مظاهر أخرى", "Aucun autre style", "No other styles"], ["لا توجد مظاهر أخرى", "Aucun autre style", "No other styles"], ["بازل – لوحة اليوم", "Puzzle – Tableau du jour", "Puzzle – Picture of the Day"], ["ابدأ اللعب أولاً", "Commencez à jouer d’abord", "Start playing first"], ["المؤثرات الصوتية", "Effets sonores", "Sound effects"], ["التحدي الأسبوعي", "Défi de la semaine", "Weekly challenge"], ["التباين العالي:", "Contraste élevé :", "High contrast:"], ["تعذّرت المشاركة", "Partage impossible", "Sharing failed"], ["المستوى التالي", "Niveau suivant", "Next level"], ["3 أيام متتالية", "3 jours d’affilée", "3-day streak"], ["إعادة المشاهدة", "Revoir", "Watch replay"], ["لوحة المتصدرين", "Classement", "Leaderboard"], ["إمكانية الوصول", "Accessibilité", "Accessibility"], ["مشاركة النتيجة", "Partager le résultat", "Share result"], ["أكمل قبل الوقت", "Terminez à temps", "Finish in time"], ["اكتملت اللوحة!", "Tableau terminé !", "Picture complete!"], ["السرعة الذهبية", "Vitesse d’or", "Golden speed"], ["تم نسخ النتيجة", "Résultat copié", "Result copied"], ["الوقت المتبقي", "Temps restant", "Time left"], ["تقليل الحركة:", "Réduire les animations :", "Reduce motion:"], ["تثبيت التطبيق", "Installer l’application", "Install app"], ["تحدّي التركيز", "Défi de concentration", "Focus challenge"], ["اللعبة متوقفة", "Jeu en pause", "Game paused"], ["الوقت المنقضي", "Temps écoulé", "Time elapsed"], ["سلسلة 7 أيام", "Série de 7 jours", "7-day streak"], ["أيام متتالية", "jours d’affilée", "day streak"], ["لوحة الأحجية", "Plateau du puzzle", "Puzzle board"], ["تدوير القطع:", "Rotation des pièces :", "Rotate pieces:"], ["تنزيل الصورة", "Télécharger l’image", "Download image"], ["نتيجة اللوحة", "Résultat du tableau", "Picture result"], ["أعد المحاولة", "Réessayer", "Try again"], ["العب من جديد", "Rejouer", "Play again"], ["محترف البازل", "Pro du puzzle", "Puzzle pro"], ["الوقت المحدد", "Temps imparti", "Time limit"], ["ألواح مكتملة", "tableaux terminés", "pictures completed"], ["تكبير اللوحة", "Agrandir le tableau", "Enlarge picture"], ["لوحة بلا خطأ", "Tableau sans faute", "Flawless picture"], ["لوحة المشرف", "Espace admin", "Admin panel"], ["مظهر اللوحة", "Apparence du plateau", "Board style"], ["طريقة اللعب", "Façon de jouer", "How to play"], ["انتهى الوقت", "Temps écoulé", "Time’s up"], ["احفظ الصورة", "Mémorisez l’image", "Memorize the picture"], ["رمز الغرفة:", "Code de la salle :", "Room code:"], ["خبير البازل", "Expert du puzzle", "Puzzle expert"], ["أكمل لوحتين", "Terminez 2 tableaux", "Complete 2 pictures"], ["أُلغي الحمل", "Prise annulée", "Pick-up cancelled"], ["بطل الأسبوع", "Champion de la semaine", "Weekly champion"], ["ملك التدوير", "Roi de la rotation", "Rotation king"], ["إنجاز جديد:", "Nouveau succès :", "New achievement:"], ["قطعة اليوم", "Pièces du jour", "Pieces today"], ["إيقاف مؤقت", "Pause", "Pause"], ["ملف اللاعب", "Profil du joueur", "Player profile"], ["اسم اللاعب", "Nom du joueur", "Player name"], ["ابدأ اللعب", "Jouer", "Start playing"], ["عرض اللوحة", "Afficher le tableau", "View picture"], ["اسحب القطع", "Glissez les pièces", "Drag the pieces"], ["أول انتصار", "Première victoire", "First win"], ["بدون تلميح", "Sans indice", "No hints"], ["مهام اليوم", "Missions du jour", "Daily missions"], ["مظهر جديد:", "Nouveau style :", "New style:"], ["الإعدادات", "Réglages", "Settings"], ["حفظ الملف", "Enregistrer le profil", "Save profile"], ["المؤثرات:", "Effets :", "Effects:"], ["الموسيقى:", "Musique :", "Music:"], ["الاهتزاز:", "Vibration :", "Vibration:"], ["الأرجواني", "Pourpre", "Purple"], ["لإسقاطها،", "pour la déposer,", "to drop it,"], ["لاعب جديد", "Nouveau joueur", "New player"], ["من اللوحة", "du tableau", "of the picture"], ["مكان خاطئ", "Mauvais emplacement", "Wrong place"], ["عشر ألواح", "Dix tableaux", "Ten pictures"], ["نجم متألق", "Étoile brillante", "Shining star"], ["إنجازاتي", "Succès", "Badges"], ["نمط هادئ", "Mode calme", "Calm mode"], ["المؤثرات", "Effets", "Effects"], ["الموسيقى", "Musique", "Music"], ["الياقوتي", "Rubis", "Ruby"], ["الفيروزي", "Turquoise", "Turquoise"], ["للتدوير،", "pour pivoter,", "to rotate,"], ["للإلغاء.", "pour annuler.", "to cancel."], ["أفضل وقت", "Meilleur temps", "Best time"], ["حفظ ونشر", "Enregistrer et publier", "Save & publish"], ["المستوى", "Niveau", "Level"], ["الألبوم", "Album", "Album"], ["إعدادات", "Réglages", "Settings"], ["الزمردي", "Émeraude", "Emerald"], ["استئناف", "Reprendre", "Resume"], ["30 نجمة", "30 étoiles", "30 stars"], ["10 نجوم", "10 étoiles", "10 stars"], ["للإسقاط", "pour la déposer", "to drop it"], ["مساعدة", "Aide", "Help"], ["مفعّلة", "activés", "on"], ["متوقفة", "désactivés", "off"], ["الذهبي", "Doré", "Gold"], ["الملكي", "Royal", "Royal"], ["أحسنت!", "Bravo !", "Well done!"], ["الاسم:", "Nom :", "Name:"], ["تلقائي", "Automatique", "Auto"], ["اختيار", "Choisir", "Choose"], ["أسطورة", "Légende", "Legend"], ["نصيحة:", "Astuce :", "Tip:"], ["لحملها", "pour la prendre", "to pick it up"], ["تدوير:", "Rotation :", "Rotation:"], ["تلميح", "Indice", "Hint"], ["تراجع", "Annuler", "Undo"], ["إعادة", "Rétablir", "Redo"], ["مفعّل", "activé", "on"], ["متوقف", "désactivé", "off"], ["اللغة", "Langue", "Language"], ["إغلاق", "Fermer", "Close"], ["مبتدئ", "Débutant", "Beginner"], ["محترف", "Pro", "Pro"], ["نجمة", "étoiles", "stars"], ["هاوٍ", "Amateur", "Amateur"], ["خبير", "Expert", "Expert"], ["نقطة", "pts", "pts"]];
const I18N_EXACT=[["تم", "OK", "Done"], ["بازل", "Puzzle", "Puzzle"], ["الوقت", "Temps", "Time"], ["قطعة", "pièces", "pieces"], ["ح", "D", "S"], ["ن", "L", "M"], ["ث", "M", "T"], ["ر", "M", "W"], ["خ", "J", "T"], ["ج", "V", "F"], ["س", "S", "S"]];
const I18N_PAT=[["بعد الضغط على «ابدأ اللعب» ستظهر الصورة (\\d+) ثوانٍ لتحفظها","Après avoir appuyé sur « Jouer », l’image s’affiche $1 secondes pour la mémoriser","After you press “Start playing”, the picture is shown for $1 seconds so you can memorize it"],["القطع المتبقية: (\\d+) من (\\d+)", "Pièces restantes : $1 sur $2", "Pieces left: $1 of $2"], ["أنجزت (\\d+) من (\\d+) قطعة — كنت قريباً!", "Vous avez placé $1 pièces sur $2 — tout près !", "You placed $1 of $2 pieces — so close!"], ["القطعة (\\d+) من (\\d+)", "Pièce $1 sur $2", "Piece $1 of $2"], ["الصف (\\d+) العمود (\\d+)", "Ligne $1, colonne $2", "Row $1, column $2"], ["اجمع (\\d+) نجمة لفتح المظهر", "Récoltez $1 étoiles pour débloquer le style", "Collect $1 stars to unlock the style"], ["حافظ على (\\d+) أيام متتالية لفتح المظهر", "Jouez $1 jours d’affilée pour débloquer le style", "Keep a $1-day streak to unlock the style"], ["فُتح المستوى (\\d+)", "Niveau $1 débloqué", "Level $1 unlocked"], ["(\\d+) فوز · أفضل وقت", "$1 victoires · meilleur temps", "$1 wins · best time"], ["(\\d+) نقطة · (\\d+) للرتبة", "$1 pts · $2 pour le rang", "$1 pts · $2 to rank"], ["أكملت لوحة (.+?) في (\\d+:\\d+)", "J’ai terminé le tableau $1 en $2", "I completed $1 in $2"]].map(x=>[new RegExp(x[0],'g'),x[1],x[2]]);

let LANG=ls.get('pz-lang','ar');if(!['ar','fr','en'].includes(LANG))LANG='ar';
const AR_RE=/[؀-ۿ]/,TITLE_AR=document.title,LANG_I=LANG==='fr'?1:2;
function translateUIString(str){
  if(LANG==='ar'||typeof str!=='string')return str;const col=LANG==='fr'?1:2;
  const tr=str.trim();for(const e of I18N_EXACT){if(tr===e[0])return str.replace(e[0],e[col])}
  let out=str;
  for(const p of I18N_PAT)out=out.replace(p[0],p[col]);
  for(const e of I18N_TABLE){if(out.includes(e[0]))out=out.split(e[0]).join(e[col])}
  return out}
function trNode(n){let orig;
  if(n._tr!==undefined&&n.nodeValue===n._tr)orig=n._ar;
  else{orig=n.nodeValue;n._ar=undefined;n._tr=undefined;if(!AR_RE.test(orig))return;n._ar=orig}
  const out=translateUIString(orig);if(out!==n.nodeValue)n.nodeValue=out;n._tr=out!==orig?out:undefined}
const TR_ATTRS=['aria-label','title','placeholder','alt'];
function trAttr(el){if(!el.hasAttribute)return;for(const a of TR_ATTRS){if(!el.hasAttribute(a))continue;const key='_a_'+a,cur=el.getAttribute(a),rec=el[key];let orig;
  if(rec&&rec.tr===cur)orig=rec.ar;else{if(!AR_RE.test(cur)){el[key]=undefined;continue}orig=cur}
  const out=translateUIString(orig);if(out!==cur)el.setAttribute(a,out);el[key]={ar:orig,tr:out}}}
function trTree(root){if(root.nodeType===3){trNode(root);return}if(root.nodeType!==1)return;const g=root.tagName;if(g==='SCRIPT'||g==='STYLE')return;trAttr(root);for(let c=root.firstChild;c;c=c.nextSibling)trTree(c)}
new MutationObserver(ms=>{if(LANG==='ar')return;for(const m of ms){
  if(m.type==='childList')m.addedNodes.forEach(trTree);
  else if(m.type==='characterData')trNode(m.target);
  else if(m.type==='attributes')trAttr(m.target)}}).observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:TR_ATTRS});
function setLang(l){LANG=l;ls.set('pz-lang',l);const h=document.documentElement;h.lang=l;h.dir=l==='ar'?'rtl':'ltr';
  trTree(document.body);document.title=translateUIString(TITLE_AR);
  document.querySelectorAll('#langSeg button').forEach(b=>{const on=b.dataset.l===l;b.classList.toggle('on',on);b.setAttribute('aria-pressed',on)})}
document.querySelectorAll('#langSeg button').forEach(b=>b.onclick=()=>setLang(b.dataset.l));
setLang(LANG);
renderRank();renderMissions();
Promise.all(Object.keys(CFG.levels||{}).map(async k=>{LI[k]=await toCanvas(CFG.levels[k])})).then(()=>{loadUnl();build()});

/* توافق اللمس: اجعل النقر على الأيقونة يصل دائماً إلى الزر الأب */
document.addEventListener('click',function(ev){
  const icon=ev.target&&ev.target.closest?ev.target.closest('button .ui-icon'):null;
  if(icon){const btn=icon.closest('button');if(btn&&ev.target!==btn){ev.preventDefault();}}
},true);

/* القائمة الجانبية: الرئيسية، الملف الشخصي، لوحة المتصدرين */
(function(){
 const backdrop=document.getElementById('bpMenuBackdrop');
 const toggle=document.getElementById('bpMenuToggle');
 const close=document.getElementById('bpMenuClose');
 if(!backdrop||!toggle||!close)return;
 function closeMenu(){backdrop.classList.remove('open');backdrop.setAttribute('aria-hidden','true');toggle.setAttribute('aria-expanded','false')}
 function openMenu(){backdrop.classList.add('open');backdrop.setAttribute('aria-hidden','false');toggle.setAttribute('aria-expanded','true')}
 toggle.addEventListener('click',()=>backdrop.classList.contains('open')?closeMenu():openMenu());
 close.addEventListener('click',closeMenu);
 backdrop.addEventListener('click',e=>{if(e.target===backdrop)closeMenu()});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu()});
 backdrop.querySelectorAll('[data-menu-action]').forEach(btn=>btn.addEventListener('click',()=>{
  const action=btn.getAttribute('data-menu-action');
  closeMenu();
  const profileBox=document.getElementById('profileBox');
  const leaderboardBox=document.getElementById('leaderboardBox');
  if(action==='home'){
   if(profileBox)profileBox.style.display='none';
   if(leaderboardBox)leaderboardBox.style.display='none';
   window.scrollTo({top:0,behavior:'smooth'});
  }else if(action==='profile'){
   if(leaderboardBox)leaderboardBox.style.display='none';
   if(profileBox){profileBox.style.display='block';if(typeof renderProfile==='function')renderProfile();profileBox.scrollIntoView({behavior:'smooth',block:'start'})}
  }else if(action==='leaders'){
   if(profileBox)profileBox.style.display='none';
   if(leaderboardBox){leaderboardBox.style.display='none';if(typeof renderLeaderboard==='function')renderLeaderboard();leaderboardBox.scrollIntoView({behavior:'smooth',block:'center'})}
  }
 }));
})();
